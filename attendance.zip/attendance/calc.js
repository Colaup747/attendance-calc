// Attendance Planner - calculator (pure JS, no DOM, no network).
// Works in Node (module.exports) and in the extension popup (globalThis.AttendanceCalc).
//
// attendance: { "YYYY-MM-DD": ["P"|"A"|"L", ...] }   one entry per lecture
// Leaves ("L") are neutral: excluded from the denominator.

const DEFAULT_LECTURES = { 0: 0, 1: 6, 2: 6, 3: 6, 4: 5, 5: 6, 6: 6 }; // Sun..Sat

const DEFAULT_WINDOWS = [
  { name: "Installment No. 2", start: "2026-08-17", end: "2026-09-14" },
  { name: "Installment No. 3", start: "2026-09-15", end: "2026-11-01" },
  { name: "Installment No. 4", start: "2026-11-02", end: "2026-12-21" },
];

// Date helpers use UTC so timezone / DST never shifts a date.
const parse = (s) => {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d));
};
const fmt = (dt) => dt.toISOString().slice(0, 10);
const addDays = (s, n) => { const d = parse(s); d.setUTCDate(d.getUTCDate() + n); return fmt(d); };
const weekday = (s) => parse(s).getUTCDay();
const WEEKDAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function pickWindow(windows, todayStr) {
  return windows.find((w) => w.end >= todayStr) || windows[windows.length - 1];
}

/**
 * opts:
 *  attendance, window {start,end}, today "YYYY-MM-DD",
 *  lecturesPerWeekday {0..6}, holidays [dates], plannedLeaves [dates],
 *  target (default 0.8),
 *  unposted { "YYYY-MM-DD": "P"|"A"|"L" }  user-marked days the portal hasn't posted
 */
function computeSkips(opts) {
  const {
    attendance, window: win, today,
    lecturesPerWeekday = DEFAULT_LECTURES,
    holidays = [], plannedLeaves = [], examDays = [], prepLeaves = [], target = 0.8, unposted = {},
  } = opts;

  const holidaySet = new Set(holidays);
  const leaveSet = new Set(plannedLeaves);
  const examSet = new Set(examDays);
  const prepSet = new Set(prepLeaves);

  // 1. Past: count P and A inside the window, up to the last posted day.
  let P = 0, A = 0, L = 0, dataThrough = null;
  for (const [date, dots] of Object.entries(attendance)) {
    if (date < win.start || date > win.end || !dots.length) continue;
    if (!dataThrough || date > dataThrough) dataThrough = date;
    for (const s of dots) { if (s === "P") P++; else if (s === "A") A++; else if (s === "L") L++; }
  }

  // 2. Future starts the day after the last posted day (or the window start).
  const futureStart = dataThrough ? addDays(dataThrough, 1) : win.start;

  // Days the portal hasn't posted yet, but the user says what happened.
  for (const [date, status] of Object.entries(unposted)) {
    if (date < futureStart || date > win.end || date > today) continue;
    if (holidaySet.has(date) || prepSet.has(date)) continue;
    if (status === "PENDING" || status === "UNSYNCED") {
      // Portal sync pending: held neutral, never penalized as an absence
      continue;
    }
    const isExam = examSet.has(date);
    const n = isExam ? 1 : (lecturesPerWeekday[weekday(date)] || 0);
    if (status === "P") P += n; else if (status === "A") A += n; else L += n;
  }
  const overridden = new Set(Object.keys(unposted));

  // 3. Future lectures F, minus holidays, preplanned leaves, and prep offs between exams.
  const futureDays = [];
  for (let d = futureStart; d <= win.end; d = addDays(d, 1)) {
    if (overridden.has(d) && d <= today) continue;
    if (holidaySet.has(d) || leaveSet.has(d) || prepSet.has(d)) continue;
    const isExam = examSet.has(d);
    const n = isExam ? 1 : (lecturesPerWeekday[weekday(d)] || 0);
    if (n > 0) futureDays.push({ date: d, day: WEEKDAY_NAMES[weekday(d)], lectures: n, isExam });
  }
  const F = futureDays.reduce((s, x) => s + x.lectures, 0);

  // 4. Max skippable lectures: (P+F-s)/(P+A+F) >= target
  const raw = (1 - target) * (P + F) - target * A;
  const sMax = Math.floor(raw + 1e-9);
  const currentPct = P + A > 0 ? (100 * P) / (P + A) : 100;
  const maxPossiblePct = (P + F) > 0 ? (100 * (P + F)) / (P + A + F) : 0;

  let leavesNeeded = 0;
  if (sMax < 0) {
    // How many past absences must be converted to approved leaves (neutral / excluded from denominator)
    // so that: (P + F) / (P + F + A - k) >= target
    // k >= A - ((1 - target) / target) * (P + F)
    const needed = A - ((1 - target) / target) * (P + F);
    leavesNeeded = Math.max(0, Math.ceil(needed - 1e-9));
  }

  const result = {
    window: win, dataThrough, P, A, L, F,
    currentPct: Math.round(currentPct * 10) / 10,
    maxPossiblePct: Math.round(maxPossiblePct * 10) / 10,
    leavesNeeded,
    sMaxLectures: sMax, mustAttendAll: sMax < 0,
    skipDays: [], fullDays: 0, extraLectures: 0, finalPctIfMaxSkipped: null,
  };
  if (sMax < 0) return result;

  // 5. Convert to whole days: lightest days first (Thursday), ties by date.
  // Only suggest days that are still ahead and not exam days.
  const sorted = futureDays.filter((d) => d.date > today && !d.isExam).sort((a, b) => a.lectures - b.lectures || (a.date < b.date ? -1 : 1));
  let budget = sMax;
  for (const d of sorted) {
    if (d.lectures <= budget) { result.skipDays.push(d); budget -= d.lectures; }
  }
  result.skipDays.sort((a, b) => (a.date < b.date ? -1 : 1));
  result.fullDays = result.skipDays.length;
  result.extraLectures = budget; // leftover lectures you may also miss, not a whole day

  const skipped = sMax; // using the full budget
  result.finalPctIfMaxSkipped =
    Math.round(((100 * (P + F - skipped)) / (P + A + F)) * 100) / 100;
  return result;
}

const api = { computeSkips, pickWindow, DEFAULT_LECTURES, DEFAULT_WINDOWS };
if (typeof module !== "undefined" && module.exports) module.exports = api;
else globalThis.AttendanceCalc = api;
