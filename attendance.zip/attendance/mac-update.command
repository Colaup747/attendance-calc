#!/bin/bash
cd "$(dirname "$0")"
echo "=================================================="
echo "    Attendance Planner - 1-Click Updater (macOS)   "
echo "=================================================="
echo ""
echo "[*] Downloading latest update from GitHub..."

TMP_DIR=$(mktemp -d)
ZIP_FILE="$TMP_DIR/update.zip"

curl -s -L "https://github.com/Colaup747/attendance-calc/archive/refs/heads/main.zip" -o "$ZIP_FILE"
if [ $? -eq 0 ] && [ -f "$ZIP_FILE" ]; then
    echo "[*] Extracting update..."
    unzip -q -o "$ZIP_FILE" -d "$TMP_DIR"
    if [ -d "$TMP_DIR/attendance-calc-main" ]; then
        cp -R "$TMP_DIR/attendance-calc-main/"* .
        rm -rf "$TMP_DIR"
        echo ""
        echo "[OK] Update successfully installed!"
        echo "[*] Open Chrome and click the reload icon in chrome://extensions"
    else
        echo "[!] Error locating extracted files."
        rm -rf "$TMP_DIR"
    fi
else
    echo "[!] Download failed. Check your internet connection."
    rm -rf "$TMP_DIR"
fi

echo ""
read -p "Press [Enter] to exit..."

