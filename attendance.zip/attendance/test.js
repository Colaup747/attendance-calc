// test.js – run with: node test.js
// Tests calc.js against the exact expected values in the spec.

const { computeSkips, DEFAULT_LECTURES } = require("./calc.js");

let passed = 0;
let failed = 0;

function assert(label, actual, expected, tolerance = 0) {
  const ok = tolerance > 0
    ? Math.abs(actual - expected) <= tolerance
    : actual === expected;
  if (ok) {
    console.log(`  ✓  ${label}`);
    passed++;
  } else {
    console.error(`  ✗  ${label}`);
    console.error(`     expected: ${expected}${tolerance ? ` (±${tolerance})` : ""}`);
    console.error(`     actual:   ${actual}`);
    failed++;
  }
}

// ─── Test data ──────────────────────────────────────────────────
const WIN = { start: "2026-09-15", end: "2026-11-01" };
const TODAY = "2026-09-28";

// Attendance as described in the spec
// 15 Sep (Tue) 6P, 16 Sep (Wed) 6A, 17 Sep (Thu) 5P,
// 18 Sep (Fri) 6L, 19 Sep (Sat) 6L,
// 21 Sep (Mon) 6P, 22 Sep (Tue) 6P, 23 Sep (Wed) 6P,
// 24 Sep (Thu) 4P, 25 Sep (Fri) 6P
const attendance = {
  "2026-09-15": Array(6).fill("P"),
  "2026-09-16": Array(6).fill("A"),
  "2026-09-17": Array(5).fill("P"),
  "2026-09-18": Array(6).fill("L"),
  "2026-09-19": Array(6).fill("L"),
  "2026-09-21": Array(6).fill("P"),
  "2026-09-22": Array(6).fill("P"),
  "2026-09-23": Array(6).fill("P"),
  "2026-09-24": Array(4).fill("P"),
  "2026-09-25": Array(6).fill("P"),
};

console.log("\n════════════════════════════════════════════════════════");
console.log("  Attendance Planner – calc.js test suite");
console.log("════════════════════════════════════════════════════════\n");
console.log("Test 1: baseline (no planned leaves, no unposted, no holidays)\n");

const r1 = computeSkips({
  attendance,
  window: WIN,
  today: TODAY,
  lecturesPerWeekday: DEFAULT_LECTURES,
  holidays: [],
  plannedLeaves: [],
  target: 0.8,
  unposted: {},
});

assert("P = 39",             r1.P,              39);
assert("A = 6",              r1.A,              6);
assert("L = 12",             r1.L,              12);
assert("F = 181",            r1.F,              181);
assert("sMaxLectures = 39",  r1.sMaxLectures,   39);
assert("fullDays = 7",       r1.fullDays,       7);
assert("extraLectures = 2",  r1.extraLectures,  2);
assert("finalPctIfMaxSkipped ≈ 80.09",
       r1.finalPctIfMaxSkipped, 80.09, 0.02);
assert("mustAttendAll = false", r1.mustAttendAll, false);

// Verify skipDays are all future (> today)
const allFuture = r1.skipDays.every((d) => d.date > TODAY);
assert("All suggested skip days are future dates", allFuture, true);

// Verify skip days are in ascending date order
const sorted = [...r1.skipDays].sort((a, b) => a.date < b.date ? -1 : 1);
const inOrder = r1.skipDays.every((d, i) => d.date === sorted[i].date);
assert("Skip days are sorted chronologically", inOrder, true);

console.log("\nTest 2: with plannedLeaves [2026-10-08, 2026-10-09] → sMaxLectures = 37\n");

const r2 = computeSkips({
  attendance,
  window: WIN,
  today: TODAY,
  lecturesPerWeekday: DEFAULT_LECTURES,
  holidays: [],
  plannedLeaves: ["2026-10-08", "2026-10-09"],
  target: 0.8,
  unposted: {},
});

assert("sMaxLectures = 37 (two leave days removed from F)", r2.sMaxLectures, 37);
assert("P still = 39", r2.P, 39);
assert("A still = 6",  r2.A, 6);

console.log("\nTest 3: mustAttendAll when in too deep (P=0, A=100, tiny future)\n");

// Use a tiny window where future lectures can't rescue attendance.
// Window: only 1 day left (Nov 1), P=0, A=100 → 100/(100+5) = 95% absent, cannot recover.
const TINY_WIN = { start: "2026-09-15", end: "2026-11-01" };
const r3 = computeSkips({
  attendance: {
    // 100 absences spread across many days; easier: put them all symbolically
    // raw = (1-0.8)*(0 + F) - 0.8*100 = 0.2*F - 80
    // With F=181 (same as before): 0.2*181 - 80 = 36.2 - 80 = -43.8 → mustAttendAll
    ...Object.fromEntries(
      // 17 days × 6 lec = 102 absences; use 15 days of 6A = 90, then 1 day of 4A = 94, need ~100
      // Actually simplest: override attendance with synthetic map that gives A=100
      // Spread across window-start dates
      [...Array(17)].map((_, k) => {
        const base = new Date(Date.UTC(2026, 8, 15)); // Sep 15
        base.setUTCDate(base.getUTCDate() + k);
        const dateStr = base.toISOString().slice(0, 10);
        return [dateStr, Array(6).fill("A")];
      })
    ),
  },
  window: TINY_WIN,
  today: "2026-09-28",
  lecturesPerWeekday: DEFAULT_LECTURES,
  holidays: [],
  plannedLeaves: [],
  target: 0.8,
  unposted: {},
});

// sMax = floor(0.2*(P + F) - 0.8*A).
// With P=0 (all A), A=17*6=102, F=181: 0.2*(0+181) - 0.8*102 = 36.2 - 81.6 = -45.4 → mustAttendAll
assert("mustAttendAll = true when too many absences vs future", r3.mustAttendAll, true);
assert("skipDays is empty when mustAttendAll", r3.skipDays.length, 0);
assert("leavesNeeded = 64 when target unreachable", r3.leavesNeeded, 64);
assert("maxPossiblePct = 59.8", r3.maxPossiblePct, 59.8);

console.log("\nTest 4: percentage formula  P/(P+A), leaves excluded\n");

const r4 = computeSkips({
  attendance: {
    "2026-09-15": ["P", "P", "P"],    // 3 P
    "2026-09-16": ["A", "A"],          // 2 A
    "2026-09-17": ["L", "L", "L", "L"], // 4 L  (excluded from denominator)
  },
  window: WIN,
  today: "2026-09-17",
  lecturesPerWeekday: DEFAULT_LECTURES,
  holidays: [],
  plannedLeaves: [],
  target: 0.8,
  unposted: {},
});

// P/(P+A) = 3/5 = 60%
assert("currentPct = 60.0 (leaves excluded from denominator)",
       r4.currentPct, 60.0);

console.log("\nTest 5: examDays count as 1 lecture and are never suggested to skip\n");

const r5 = computeSkips({
  attendance,
  window: WIN,
  today: TODAY,
  lecturesPerWeekday: DEFAULT_LECTURES,
  holidays: [],
  plannedLeaves: [],
  examDays: ["2026-10-01", "2026-10-02"], // 10-01 is Thu (normally 5), 10-02 is Fri (normally 6)
  target: 0.8,
  unposted: {},
});

// F was 181. Thu was 5 (now 1, -4), Fri was 6 (now 1, -5). Total F reduced by 9 -> F = 172
assert("F = 172 with two exam days reduced to 1 lecture each", r5.F, 172);
const examInSkips = r5.skipDays.some(d => d.date === "2026-10-01" || d.date === "2026-10-02");
assert("Exam days are never suggested as absence days", examInSkips, false);

console.log("\nTest 6: prepLeaves (prep offs between exams) excluded from F\n");

const r6 = computeSkips({
  attendance,
  window: WIN,
  today: TODAY,
  lecturesPerWeekday: DEFAULT_LECTURES,
  holidays: [],
  plannedLeaves: [],
  examDays: ["2026-10-01", "2026-10-05"],
  prepLeaves: ["2026-10-02", "2026-10-03"], // Fri (6 lec) + Sat (6 lec) = 12 lectures off
  target: 0.8,
  unposted: {},
});

// Without prepLeaves, F would be: 181 - 4 (10-01 Thu exam) - 5 (10-05 Mon exam) = 172.
// Prep leaves remove 10-02 (Fri 6) and 10-03 (Sat 6) = -12 -> F = 160
assert("F = 160 with prep offs between exams excluded", r6.F, 160);

console.log("\nTest 7: unposted exam with PENDING status is held neutral (no absence penalty)\n");

const r7 = computeSkips({
  attendance: {
    "2026-09-15": ["P", "P", "P", "P", "P", "P"],
  },
  window: WIN,
  today: "2026-09-17",
  lecturesPerWeekday: DEFAULT_LECTURES,
  holidays: [],
  plannedLeaves: [],
  examDays: ["2026-09-16"], // 16 Sep was an exam day, but portal didn't post
  target: 0.8,
  unposted: {
    "2026-09-16": "PENDING", // Marked as not synced yet
  },
});

assert("A = 0 when unsynced exam is marked PENDING", r7.A, 0);
assert("P = 6 from 15 Sep", r7.P, 6);

console.log("\n════════════════════════════════════════════════════════");
console.log(`  Results: ${passed} passed, ${failed} failed`);
console.log("════════════════════════════════════════════════════════\n");

if (failed > 0) process.exit(1);
