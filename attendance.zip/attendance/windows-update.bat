@echo off
setlocal
title Attendance Planner - Windows Auto Updater
echo ========================================================
echo        Attendance Planner - 1-Click Updater
echo ========================================================
echo.
echo [*] Downloading latest update from GitHub...

powershell -NoProfile -Command "$ErrorActionPreference = 'Stop'; try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $zipUrl = 'https://github.com/Colaup747/attendance-calc/archive/refs/heads/main.zip'; $tmpZip = Join-Path $env:TEMP 'attendance_update.zip'; $tmpDir = Join-Path $env:TEMP 'attendance_extracted'; if (Test-Path $tmpZip) { Remove-Item $tmpZip -Force }; if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force }; Write-Host '[*] Fetching latest files from GitHub...'; Invoke-WebRequest -Uri $zipUrl -OutFile $tmpZip -UseBasicParsing; Write-Host '[*] Extracting update...'; Expand-Archive -Path $tmpZip -DestinationPath $tmpDir -Force; $src = Join-Path $tmpDir 'attendance-calc-main'; if (Test-Path $src) { Copy-Item -Path ($src + '\*') -Destination '.' -Recurse -Force; Remove-Item $tmpZip -Force; Remove-Item $tmpDir -Recurse -Force; Write-Host '[OK] Update successfully installed!' -ForegroundColor Green } else { throw 'Could not locate extracted folder' } } catch { Write-Host '[!] Error downloading update: ' $_.Exception.Message -ForegroundColor Red; pause }"

echo.
echo [*] Update complete! Open chrome://extensions and click the reload icon.
echo.
pause

