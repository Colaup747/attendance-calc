// Attendance Planner - content script for https://my.pgc.edu/*
// Reads the v-calendar attendance view, walks back month by month, and saves
// {date: ["P"|"A"|"L", ...]} to chrome.storage.local. No tokens, no network.
// Optimized for slow internet connections and auto-heals PGC's initial blank calendar bug.

const TERM_START = { year: 2026, month: 8 }; // August 2026 (1-based)
const STATUS = { blue: "P", red: "A", gray: "L" }; // P=attended, A=absent, L=leave

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const titleEl = () => document.querySelector(".vc-title");
const leftArrow = () => document.querySelector(".vc-arrow.is-left");
const rightArrow = () => document.querySelector(".vc-arrow.is-right");

// Auto-heal PGC's blank calendar bug:
// When navigating to /attend for the first time in a session, PGC's SPA frequently mounts
// an empty container until a page reload is triggered.
if (window.location.pathname.startsWith("/attend")) {
  setTimeout(() => {
    const hasCal = !!document.querySelector(".vc-container, .vc-title");
    const didReload = sessionStorage.getItem("ap_did_reload");
    if (!hasCal && !didReload) {
      sessionStorage.setItem("ap_did_reload", "true");
      console.log("[AttendancePlanner] Blank calendar detected on initial visit. Auto-reloading to fix portal display...");
      window.location.reload();
    }
  }, 2500);
}

function classify(style) {
  const m = /var\(--(\w+)-\d+\)/.exec(style || "");
  return m ? STATUS[m[1]] || "?" : "?";
}

// Reads the month currently on screen. Ignores days from adjacent months.
function readVisibleMonth() {
  const days = {};
  document.querySelectorAll(".vc-day.in-month").forEach((d) => {
    const m = d.className.match(/id-(\d{4}-\d\d-\d\d)/);
    if (!m) return;
    const dots = [...d.querySelectorAll(".vc-dot")].map((x) =>
      classify(x.getAttribute("style"))
    );
    if (dots.length) days[m[1]] = dots;
  });
  return days;
}

// Portal's own totals for the visible month, used as a sanity check.
function readPortalTotals() {
  const t = document.body ? document.body.innerText : "";
  const g = (label) => {
    const m = new RegExp(label + ":\\s*(\\d+)\\s*/\\s*(\\d+)", "i").exec(t);
    return m ? Number(m[1]) : null;
  };
  return { present: g("PRESENT"), absent: g("ABSENT"), leaves: g("LEAVES") };
}

function monthOfTitle() {
  const el = titleEl();
  if (!el || !el.innerText || !el.innerText.trim()) {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() + 1 };
  }
  const clean = el.innerText.trim();
  const d = new Date(clean + " 1");
  if (isNaN(d.getTime())) {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() + 1 };
  }
  return { year: d.getFullYear(), month: d.getMonth() + 1 };
}

// Wait up to timeoutMs for the calendar to be present in the DOM
async function waitForCalendar(timeoutMs = 15000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (titleEl() && (leftArrow() || rightArrow())) {
      // Clear auto-reload session flag once calendar is active
      sessionStorage.removeItem("ap_did_reload");
      return true;
    }
    // If not mounted yet and we're on /attend, attempt one automatic reload after 3s
    if (Date.now() - start > 3000 && !sessionStorage.getItem("ap_did_reload") && window.location.pathname.startsWith("/attend")) {
      sessionStorage.setItem("ap_did_reload", "true");
      console.log("[AttendancePlanner] Calendar not mounted after 3s. Reloading page...");
      window.location.reload();
      await sleep(5000);
      return false;
    }
    await sleep(150);
  }
  return !!titleEl();
}

// Robust adaptive wait for dots to render even on high-latency / slow connections
async function waitForDotsToSettle(maxWaitMs = 12000) {
  const startTime = Date.now();
  let lastDotCount = -1;
  let stableTicks = 0;

  while (Date.now() - startTime < maxWaitMs) {
    const currentDots = document.querySelectorAll(".vc-day.in-month .vc-dot").length;
    const totals = readPortalTotals();
    const portalExpected = (totals.present || 0) + (totals.absent || 0) + (totals.leaves || 0);

    // If portal bottom totals specify a count (e.g. 24) and we matched/exceeded it, we are ready!
    if (portalExpected > 0 && currentDots >= portalExpected) {
      await sleep(250);
      return;
    }

    // If dots are appearing and count stays unchanged for 4 consecutive checks (400ms):
    if (currentDots > 0) {
      if (currentDots === lastDotCount) {
        stableTicks++;
        if (stableTicks >= 4) {
          await sleep(200);
          return;
        }
      } else {
        lastDotCount = currentDots;
        stableTicks = 0;
      }
    }

    // If genuinely empty month after waiting at least 4s and no portal totals:
    if (currentDots === 0 && (Date.now() - startTime > 4000) && portalExpected === 0) {
      return;
    }

    await sleep(100);
  }
  await sleep(250);
}

async function clickAndWait(btn) {
  const before = titleEl() ? titleEl().innerText : "";
  btn.click();
  for (let i = 0; i < 60; i++) {
    await sleep(100);
    const cur = titleEl() ? titleEl().innerText : "";
    if (cur && cur !== before) break;
  }
  // Adaptive dot wait that accommodates slow internet without stalling fast connections
  await waitForDotsToSettle(12000);
}

// Navigate the v-calendar to today's month before scraping so that Calculate always
// captures the most recent data regardless of which month was currently open.
async function navigateToCurrentMonth() {
  const now = new Date();
  const targetYear  = now.getFullYear();
  const targetMonth = now.getMonth() + 1; // 1-based
  for (let guard = 0; guard < 24; guard++) {
    const cur = monthOfTitle();
    if (cur.year === targetYear && cur.month === targetMonth) break;
    if (cur.year < targetYear || (cur.year === targetYear && cur.month < targetMonth)) {
      const btn = rightArrow();
      if (!btn) break;
      await clickAndWait(btn);
    } else {
      const btn = leftArrow();
      if (!btn) break;
      await clickAndWait(btn);
    }
  }
}

async function scrapeAll() {
  const hasCal = await waitForCalendar(15000);
  if (!hasCal) {
    throw new Error(
      "Attendance calendar was not detected. Please ensure you are logged into my.pgc.edu/attend and reload the page."
    );
  }

  const all = {};
  const warnings = [];
  let stepsBack = 0;

  // Retrieve existing stored attendance as a fallback for slow internet / network drops
  const stored = await chrome.storage.local.get("attendance");
  const existing = (stored && stored.attendance) || {};

  // Always start from today's month so we don't miss recent attendance.
  await navigateToCurrentMonth();

  const now = new Date();
  const targetYear  = now.getFullYear();
  const targetMonth = now.getMonth() + 1;

  for (let guard = 0; guard < 24; guard++) {
    const month = readVisibleMonth();
    const counts = { P: 0, A: 0, L: 0 };
    Object.values(month).flat().forEach((s) => (counts[s] = (counts[s] || 0) + 1));
    const totals = readPortalTotals();
    const cur = monthOfTitle();

    // The portal summary text on the page reflects the current active month.
    // Only perform the sanity check on the current month, and only if totals exist.
    const isCurrentMonth = (cur.year === targetYear && cur.month === targetMonth);
    if (
      isCurrentMonth &&
      totals.present !== null &&
      (counts.P !== totals.present || counts.A !== totals.absent || counts.L !== totals.leaves)
    ) {
      warnings.push(`${titleEl() ? titleEl().innerText : "Current month"}: scraped ${JSON.stringify(counts)} vs portal ${JSON.stringify(totals)}`);
    }
    Object.assign(all, month);

    if (cur.year === TERM_START.year && cur.month <= TERM_START.month) break;
    if (cur.year < TERM_START.year) break;
    const btn = leftArrow();
    if (!btn) { warnings.push("Previous-month arrow not found"); break; }
    await clickAndWait(btn);
    stepsBack++;
  }

  for (let i = 0; i < stepsBack; i++) { // return to today's month
    const btn = rightArrow();
    if (!btn) break;
    await clickAndWait(btn);
  }

  // Intelligent non-destructive merge:
  // Group existing and newly scraped attendance by month (YYYY-MM).
  // If a month in the new scrape has fewer dots than previously verified in storage
  // (e.g. due to slow network timeout or dropped packets), preserve existing verified data!
  const finalAttendance = Object.assign({}, existing);

  // Group new scrape by month
  const newByMonth = {};
  for (const [date, dots] of Object.entries(all)) {
    const mKey = date.slice(0, 7);
    if (!newByMonth[mKey]) newByMonth[mKey] = {};
    newByMonth[mKey][date] = dots;
  }

  // Group existing by month
  const existByMonth = {};
  for (const [date, dots] of Object.entries(existing)) {
    const mKey = date.slice(0, 7);
    if (!existByMonth[mKey]) existByMonth[mKey] = {};
    existByMonth[mKey][date] = dots;
  }

  for (const [mKey, days] of Object.entries(newByMonth)) {
    const newCount = Object.values(days).reduce((s, dots) => s + dots.length, 0);
    const oldCount = existByMonth[mKey]
      ? Object.values(existByMonth[mKey]).reduce((s, dots) => s + dots.length, 0)
      : 0;

    if (oldCount > newCount && newCount === 0) {
      warnings.push(`Network lag on ${mKey}: preserved previously verified attendance (${oldCount} lectures).`);
    } else {
      // Apply fresh data
      for (const [d, dots] of Object.entries(days)) {
        finalAttendance[d] = dots;
      }
    }
  }

  await chrome.storage.local.set({
    attendance: finalAttendance,
    scrapedAt: new Date().toISOString(),
    warnings,
  });
  return { days: Object.keys(finalAttendance).length, warnings };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "SCRAPE_ALL") {
    scrapeAll().then(sendResponse).catch((e) => sendResponse({ error: String(e.message || e) }));
    return true; // async response
  }
});
