#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [ -f "$DIR/updater/mac-update.command" ]; then
    exec "$DIR/updater/mac-update.command" "$@"
else
    echo "[!] updater/mac-update.command not found."
    read -p "Press [Enter] to exit..."
fi
