// Attendance Planner – popup.js  (v3 – fully guarded init)
//
// Design rule: NOTHING that can throw runs at module level.
// All DOM access, all calc references, all event wiring happens
// inside init() which is wrapped in a top-level window.onerror +
// a try/catch, so any crash is visible in the red banner.

/* ─── top-level safety net ─────────────────────────────────────── */
window.onerror = function (msg, src, line, col, err) {
  var banner = document.getElementById("err-banner");
  var text   = document.getElementById("err-text");
  if (banner && text) {
    text.textContent = "JS error: " + (err ? err.message : msg) +
                       " (line " + line + ")";
    banner.classList.add("visible");
  }
  console.error("[AP]", msg, src, line, col, err);
  return false; // let it also log normally
};

/* ─── defer everything until DOM + calc.js are ready ──────────── */
document.addEventListener("DOMContentLoaded", function () {
  try {
    init();
  } catch (e) {
    console.error("[AP] init threw:", e);
    var banner = document.getElementById("err-banner");
    var text   = document.getElementById("err-text");
    if (banner && text) {
      text.textContent = "Startup error: " + e.message;
      banner.classList.add("visible");
    }
  }
});

/* ═══════════════════════════════════════════════════════════════ */
function init() {
  /* ── calc.js API ──────────────────────────────────────────── */
  // Read through window so we get a clear "AttendanceCalc is not
  // defined on window" message instead of a cryptic ReferenceError.
  var api = window["AttendanceCalc"];
  if (!api) throw new Error(
    "calc.js did not load – AttendanceCalc not found on window."
  );
  var computeSkips   = api.computeSkips;
  var pickWindow     = api.pickWindow;
  var DEFAULT_LECTURES = api.DEFAULT_LECTURES;
  var DEFAULT_WINDOWS  = api.DEFAULT_WINDOWS;

  /* ── constants ────────────────────────────────────────────── */
  var DAY_NAMES = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  var MONTHS    = ["Jan","Feb","Mar","Apr","May","Jun",
                   "Jul","Aug","Sep","Oct","Nov","Dec"];
  var FULL_MONTH_NAMES = [
    "January","February","March","April","May","June",
    "July","August","September","October","November","December"
  ];

  /* ── state ────────────────────────────────────────────────── */
  var attendance       = null;
  var scrapedAt        = null;
  var warnings         = [];
  var settings         = null;
  var activeWindowIdx  = 0;

  var calNow           = new Date();
  var leavesCalYear    = calNow.getFullYear();
  var leavesCalMonth   = calNow.getMonth();
  var examsCalYear     = calNow.getFullYear();
  var examsCalMonth    = calNow.getMonth();
  var holidaysCalYear  = calNow.getFullYear();
  var holidaysCalMonth = calNow.getMonth();

  /* ── helpers ──────────────────────────────────────────────── */
  function $$(id) { return document.getElementById(id); }

  function todayStr() {
    var d = new Date();
    return [d.getFullYear(),
            pad(d.getMonth() + 1),
            pad(d.getDate())].join("-");
  }
  function pad(n) { return String(n).padStart(2, "0"); }

  function weekdayOf(s) {
    var p = s.split("-").map(Number);
    return new Date(Date.UTC(p[0], p[1]-1, p[2])).getUTCDay();
  }
  function fmtDate(s) {
    var p = s.split("-").map(Number);
    return p[2] + " " + MONTHS[p[1]-1] + " " + p[0];
  }
  function fmtTime(iso) {
    if (!iso) return "";
    return new Date(iso).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
  }
  function escHtml(s) {
    return String(s)
      .replace(/&/g,"&amp;").replace(/</g,"&lt;")
      .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }

  /* ── storage ──────────────────────────────────────────────── */
  function loadAll() {
    return chrome.storage.local.get(
      ["attendance","scrapedAt","warnings","ap_settings"]
    ).then(function(raw) {
      attendance = raw["attendance"] || null;
      scrapedAt  = raw["scrapedAt"]  || null;
      warnings   = raw["warnings"]   || [];
      var saved  = raw["ap_settings"] || {};
      settings = {
        lecturesPerWeekday: saved.lecturesPerWeekday ||
          Object.assign({}, DEFAULT_LECTURES),
        target:        (saved.target != null) ? saved.target : 80,
        holidays:      saved.holidays      || [],
        windows:       saved.windows       ||
          DEFAULT_WINDOWS.map(function(w){return Object.assign({},w);}),
        plannedLeaves: saved.plannedLeaves || [],
        unposted:      saved.unposted      || {},
        examDays:      saved.examDays      || [],
        prepLeaves:    saved.prepLeaves    || [],
        groupCode:          saved.groupCode          || "",
        groupUsername:      saved.groupUsername      || "",
        groupPinHash:       saved.groupPinHash       || "",
        groupUserRole:      saved.groupUserRole      || "",
        groupPermissions:   saved.groupPermissions   || null,
        groupAutoSync:      (saved.groupAutoSync !== undefined) ? !!saved.groupAutoSync : true,
        groupLastSync:      saved.groupLastSync      || null,
        customFirebaseUrl:  saved.customFirebaseUrl  || "",
        lastAckedScheduleUpdate: saved.lastAckedScheduleUpdate || "",
        pendingScheduleNotice:   saved.pendingScheduleNotice   || null,
        skipPreference:          saved.skipPreference          || "max_days",
        simpleMode:              (saved.simpleMode !== undefined) ? !!saved.simpleMode : true,
        isDevMode:               !!saved.isDevMode,
      };
    });
  }
  function saveSettings() {
    chrome.storage.local.set({"ap_settings": settings});
  }

  /* ── DOM elements (safe – inside init, DOM is ready) ─────── */
  var tabBtns        = document.querySelectorAll(".tab-btn");
  var panels         = document.querySelectorAll(".panel");

  var btnSync        = $$("btn-sync");
  var syncIcon       = $$("sync-icon");
  var syncLabel      = $$("sync-label");
  var syncMeta       = $$("sync-meta");

  var warnBanner     = $$("warn-banner");
  var warnText       = $$("warn-text");
  var errBanner      = $$("err-banner");
  var errText        = $$("err-text");

  var windowSelect   = $$("window-select");
  var quickEnd       = $$("quick-end");
  var btnModeSimple   = $$("btn-mode-simple");
  var btnModeAdvanced = $$("btn-mode-advanced");
  var noWindowNotice = $$("no-window-notice");
  var noDataNotice   = $$("no-data-notice");

  var manualToggle   = $$("manual-toggle");
  var manualInputs   = $$("manual-inputs");
  var manualP        = $$("manual-p");
  var manualA        = $$("manual-a");

  var resultCard     = $$("result-card");
  var resultHeadline = $$("result-headline");
  var hNum           = $$("h-num");
  var hSub           = $$("h-sub");
  var resultSub      = $$("result-sub");
  var statusBadge    = $$("status-badge");
  var statusText     = $$("status-text");

  var simpleScheduleCard  = $$("simple-schedule-card");
  var simpleSchedGroupTag = $$("simple-sched-group-tag");
  var simpleExamsList     = $$("simple-exams-list");
  var simplePrepList      = $$("simple-prep-list");
  var simpleHolidaysList  = $$("simple-holidays-list");

  var statP          = $$("stat-p");
  var statA          = $$("stat-a");
  var statL          = $$("stat-l");
  var statF          = $$("stat-f");

  var pctBar         = $$("pct-bar");
  var pctLabel       = $$("pct-label");
  var dataThrough    = $$("data-through");

  var skipSection    = $$("skip-section");
  var skipTitle      = $$("skip-title");
  var skipList       = $$("skip-list");
  var btnStratMaxDays= $$("btn-strat-max-days");
  var btnStratHeavy  = $$("btn-strat-heavy");
  var radioStratMaxDays = $$("radio-strat-max-days");
  var radioStratHeavy   = $$("radio-strat-heavy");

  var unpostedSection= $$("unposted-section");
  var unpostedList   = $$("unposted-list");

  var calPrevLeaves   = $$("cal-prev-leaves");
  var calTitleLeaves  = $$("cal-title-leaves");
  var calNextLeaves   = $$("cal-next-leaves");
  var calGridLeaves   = $$("cal-grid-leaves");
  var leaveList       = $$("leave-list");

  var hBadgeRow       = $$("h-badge-row");
  var examEditMode    = "exam"; // "exam" or "prep"
  var btnModeExam     = $$("btn-mode-exam");
  var btnModePrep     = $$("btn-mode-prep");
  var btnAutofillPrep = $$("btn-autofill-prep");
  var calPrevExams    = $$("cal-prev-exams");
  var calTitleExams   = $$("cal-title-exams");
  var calNextExams    = $$("cal-next-exams");
  var calGridExams    = $$("cal-grid-exams");
  var examList        = $$("exam-list");
  var prepList        = $$("prep-list");

  var groupAuthBlock      = $$("group-auth-block");
  var tabAuthJoin         = $$("tab-auth-join");
  var tabAuthCreate       = $$("tab-auth-create");
  var authPanelJoin       = $$("auth-panel-join");
  var authPanelCreate     = $$("auth-panel-create");
  var groupCodeInput      = $$("group-code-input");
  var groupUsernameInput  = $$("group-username-input");
  var groupPinInput       = $$("group-pin-input");
  var btnGroupLogin       = $$("btn-group-login");
  var createGroupCodeInput= $$("create-group-code-input");
  var createGroupUsernameInput = $$("create-group-username-input");
  var createGroupPinInput = $$("create-group-pin-input");
  var btnGroupCreate      = $$("btn-group-create");
  var groupBtnGrid        = $$("group-btn-grid");
  var btnGroupPull        = $$("btn-group-pull");
  var btnGroupPush        = $$("btn-group-push");
  var groupStatus         = $$("group-status");
  var userRoleBadge       = $("user-role-badge");
  var cloudConnDot        = $("cloud-conn-dot");
  var cloudConnText       = $("cloud-conn-text");
  var groupAutosyncToggle = $$("group-autosync-toggle");
  var btnShareCode        = $$("btn-share-code");
  var btnLogoutGroup      = $$("btn-logout-group");
  var adminActionsWrap    = $$("admin-actions-wrap");
  var btnToggleAdminPanel = $$("btn-toggle-admin-panel");

  var adminPermSection    = $$("admin-perm-section");
  var adminMemberList     = $$("admin-member-list");
  var btnSaveMemberPerms  = $$("btn-save-member-perms");
  var btnRefreshMembers   = $$("btn-refresh-members");

  var otaBanner           = $$("ota-banner");
  var otaTitle            = $$("ota-title");
  var otaNotes            = $$("ota-notes");
  var btnOtaHow           = $$("btn-ota-how");
  var btnOtaReloadApp     = $$("btn-ota-reload-app");
  var updateGuideModal    = $$("update-guide-modal");
  var btnCloseUpdateGuide = $$("btn-close-update-guide");
  var btnModalOpenExt     = $$("btn-modal-open-ext");
  var btnModalReload      = $$("btn-modal-reload");
  var btnExamsSaveCloud   = $$("btn-exams-save-cloud");
  var examsCloudStatus    = $$("exams-cloud-status");
  var syncAlertBanner     = $$("sync-alert-banner");
  var syncAlertTitle      = $$("sync-alert-title");
  var syncAlertBody       = $$("sync-alert-body");
  var btnDismissSyncAlert = $$("btn-dismiss-sync-alert");
  var adminOtaVer         = $$("admin-ota-ver");
  var adminOtaUrl         = $$("admin-ota-url");
  var adminOtaNotes       = $$("admin-ota-notes");
  var btnAdminBroadcastOta= $$("btn-admin-broadcast-ota");
  var curVerTag           = $$("current-version-tag");
  var appUpdateStatus     = $$("app-update-status");
  var btnManualCheckOta   = $$("btn-manual-check-ota");
  var adminOtaPanel       = $$("admin-ota-broadcast-panel");

  var fbConfigToggleBtn   = $$("fb-config-toggle-btn");
  var fbConfigArrow       = $$("fb-config-arrow");
  var fbConfigBody        = $$("fb-config-body");
  var customFbUrlInput    = $$("custom-fb-url-input");

  var lecturesGrid    = $$("lectures-grid");
  var targetInput     = $$("target-input");
  var calPrevHolidays  = $$("cal-prev-holidays");
  var calTitleHolidays = $$("cal-title-holidays");
  var calNextHolidays  = $$("cal-next-holidays");
  var calGridHolidays  = $$("cal-grid-holidays");
  var holidayList      = $$("holiday-list");
  var windowsList     = $$("windows-list");
  var overlapWarn    = $$("overlap-warn");
  var btnAddWindow   = $$("btn-add-window");
  var btnResetWindows= $$("btn-reset-windows");

  var hasLocalEdits = false;

  /* ── banners ──────────────────────────────────────────────── */
  function renderScheduleNotice() {
    if (!syncAlertBanner) return;
    var n = settings.pendingScheduleNotice;
    if (n && n.updatedAt && n.updatedAt !== settings.lastAckedScheduleUpdate) {
      syncAlertBanner.style.display = "block";
      var t = n.title || "Schedule Updated!";
      t = t.replace(/^🔔\s*/, "");
      if (syncAlertTitle) syncAlertTitle.textContent = t;
      if (syncAlertBody) syncAlertBody.textContent = n.body || "Shared schedule was updated. Attendance recalculated.";
    } else {
      syncAlertBanner.style.display = "none";
    }
  }

  if (btnDismissSyncAlert) {
    btnDismissSyncAlert.addEventListener("click", function() {
      if (settings.pendingScheduleNotice) {
        settings.lastAckedScheduleUpdate = settings.pendingScheduleNotice.updatedAt;
        settings.pendingScheduleNotice = null;
        saveSettings();
      }
      if (syncAlertBanner) syncAlertBanner.style.display = "none";
    });
  }

  function showError(msg) {
    errText.textContent = msg;
    errBanner.classList.add("visible");
  }
  function clearError() {
    errBanner.classList.remove("visible");
  }
  function showWarnings(msgs) {
    if (!msgs || !msgs.length) {
      warnBanner.classList.remove("visible"); return;
    }
    warnText.textContent = msgs.join("\n");
    warnBanner.classList.add("visible");
  }

  /* ── tabs ─────────────────────────────────────────────────── */
  tabBtns.forEach(function(btn) {
    btn.addEventListener("click", function() {
      tabBtns.forEach(function(b){ b.classList.remove("active"); });
      panels.forEach(function(p){ p.classList.remove("active"); });
      btn.classList.add("active");
      $$("panel-" + btn.dataset.tab).classList.add("active");
    });
  });

  /* ── calculate & portal direct ────────────────────────────── */
  btnSync.addEventListener("click", function() {
    clearError();
    hasLocalEdits = false; // Reset local edits so fresh data is synced
    triggerAutoSync(true);
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if (chrome.runtime.lastError) {
        showError("Tab query error: " + chrome.runtime.lastError.message);
        return;
      }
      var tab = tabs && tabs[0];
      if (tab && tab.url && tab.url.indexOf("https://my.pgc.edu/attend") === 0) {
        // Already on Attendance page!
        setCalculating(true, "Calculating\u2026");
        doScrape(tab, false);
        return;
      }

      if (tab && tab.url && tab.url.indexOf("https://my.pgc.edu/") === 0) {
        // On another PGC portal page -> navigate to /attend and reload to fix PGC bug
        navigateAndScrape(tab.id, "https://my.pgc.edu/attend", true);
        return;
      }

      // Not currently on my.pgc.edu: check if another tab has portal open
      chrome.tabs.query({url: "*://my.pgc.edu/*"}, function(existing) {
        if (existing && existing.length > 0) {
          var targetTab = existing[0];
          chrome.tabs.update(targetTab.id, {active: true}, function() {
            if (targetTab.url && targetTab.url.indexOf("https://my.pgc.edu/attend") === 0) {
              setCalculating(true, "Calculating\u2026");
              doScrape(targetTab, false);
            } else {
              navigateAndScrape(targetTab.id, "https://my.pgc.edu/attend", true);
            }
          });
        } else {
          // Open fresh tab to https://my.pgc.edu/attend and reload it to ensure attendance renders
          chrome.tabs.create({url: "https://my.pgc.edu/attend", active: true}, function(newTab) {
            navigateAndScrape(newTab.id, null, true);
          });
        }
      });
    });
  });

  function navigateAndScrape(tabId, targetUrl, requireReload) {
    setCalculating(true, targetUrl ? "Opening portal\u2026" : "Connecting\u2026");

    function executeReloadAndScrape() {
      setCalculating(true, "Reloading page to display attendance\u2026");
      chrome.tabs.reload(tabId, function() {
        function onReloadDone(reloadedId, info) {
          if (reloadedId === tabId && info.status === "complete") {
            chrome.tabs.onUpdated.removeListener(onReloadDone);
            setCalculating(true, "Reading attendance\u2026");
            setTimeout(function() {
              chrome.tabs.get(tabId, function(currentTab) {
                if (currentTab) doScrape(currentTab, false);
              });
            }, 1500);
          }
        }
        chrome.tabs.onUpdated.addListener(onReloadDone);
      });
    }

    if (targetUrl) {
      chrome.tabs.update(tabId, { url: targetUrl, active: true }, function() {
        function onNavDone(navId, info) {
          if (navId === tabId && info.status === "complete") {
            chrome.tabs.onUpdated.removeListener(onNavDone);
            setTimeout(executeReloadAndScrape, 400);
          }
        }
        chrome.tabs.onUpdated.addListener(onNavDone);
      });
    } else if (requireReload) {
      function onInitialLoad(navId, info) {
        if (navId === tabId && info.status === "complete") {
          chrome.tabs.onUpdated.removeListener(onInitialLoad);
          setTimeout(executeReloadAndScrape, 400);
        }
      }
      chrome.tabs.onUpdated.addListener(onInitialLoad);
    } else {
      chrome.tabs.get(tabId, function(currentTab) {
        if (currentTab) doScrape(currentTab, false);
      });
    }
  }

  function setCalculating(on, label) {
    btnSync.disabled = on;
    if (on) {
      syncIcon.innerHTML = '<span class="spinner"></span>';
      syncLabel.textContent = label || "Calculating\u2026";
    } else {
      syncIcon.textContent = "\u27f3";
      syncLabel.textContent = "Calculate";
    }
  }

  function doScrape(tab, retry) {
    chrome.tabs.sendMessage(tab.id, {type:"SCRAPE_ALL"}, function(resp) {
      if (chrome.runtime.lastError) {
        if (retry) {
          setCalculating(false);
          showError("Content script not responding. Refresh the attendance page and try again.");
          return;
        }
        // Inject content script and retry once
        chrome.scripting.executeScript(
          {target:{tabId:tab.id}, files:["content.js"]},
          function() {
            if (chrome.runtime.lastError) {
              setCalculating(false);
              showError("Could not inject script: " + chrome.runtime.lastError.message);
              return;
            }
            setTimeout(function(){ doScrape(tab, true); }, 800);
          }
        );
        return;
      }
      if (resp && resp.error) {
        if (!retry && (resp.error.indexOf("not detected") !== -1 || resp.error.indexOf("Blank calendar") !== -1 || resp.error.indexOf("Cannot read") !== -1)) {
          // Automatic recovery for PGC initial blank calendar bug
          setCalculating(true, "Reloading page to fix portal display\u2026");
          chrome.tabs.reload(tab.id, function() {
            function onReloadDone(reloadedId, info) {
              if (reloadedId === tab.id && info.status === "complete") {
                chrome.tabs.onUpdated.removeListener(onReloadDone);
                setTimeout(function() {
                  doScrape(tab, true);
                }, 1500);
              }
            }
            chrome.tabs.onUpdated.addListener(onReloadDone);
          });
          return;
        }
        setCalculating(false);
        showError("Scrape error: " + resp.error);
        return;
      }
      loadAll().then(function() {
        setCalculating(false);
        renderAll();
      });
    });
  }

  /* ── window selector ──────────────────────────────────────── */
  function buildWindowSelect() {
    var wins  = settings.windows;
    var today = todayStr();
    if (!wins.length) return;

    var best = pickWindow(wins, today);
    activeWindowIdx = wins.indexOf(best);
    if (activeWindowIdx === -1) activeWindowIdx = wins.length - 1;

    var curWin = wins[activeWindowIdx];
    if (curWin && curWin.start) {
      var dMatch = (today >= curWin.start && today <= curWin.end) ? today : curWin.start;
      var parts = dMatch.split("-").map(Number);
      leavesCalYear = parts[0];
      leavesCalMonth = parts[1] - 1;
      examsCalYear = parts[0];
      examsCalMonth = parts[1] - 1;
      holidaysCalYear = parts[0];
      holidaysCalMonth = parts[1] - 1;
    }

    windowSelect.innerHTML = wins.map(function(w,i){
      return '<option value="'+i+'">'+escHtml(w.name)+
             " ("+w.start+" \u2013 "+w.end+")</option>";
    }).join("");
    windowSelect.value = String(activeWindowIdx);
    updateQuickEnd();
  }

  function updateQuickEnd() {
    var w = settings.windows[activeWindowIdx];
    if (w) quickEnd.value = w.end;
  }

  windowSelect.addEventListener("change", function() {
    activeWindowIdx = Number(windowSelect.value);
    updateQuickEnd();
    var curWin = settings.windows[activeWindowIdx];
    if (curWin && curWin.start) {
      var today = todayStr();
      var dMatch = (today >= curWin.start && today <= curWin.end) ? today : curWin.start;
      var parts = dMatch.split("-").map(Number);
      leavesCalYear = parts[0];
      leavesCalMonth = parts[1] - 1;
      examsCalYear = parts[0];
      examsCalMonth = parts[1] - 1;
      holidaysCalYear = parts[0];
      holidaysCalMonth = parts[1] - 1;
      renderLeavesCalendar();
      renderExamsCalendar();
      renderHolidaysCalendar();
    }
    renderModeUI();
    renderUnposted();
    renderStrategyUI();
    renderResult();
    renderSimpleSchedule();
  });

  quickEnd.addEventListener("change", function() {
    var w = settings.windows[activeWindowIdx];
    if (!w) return;
    var newEnd = quickEnd.value;
    if (!newEnd || newEnd < w.start) { quickEnd.value = w.end; return; }
    w.end = newEnd;
    saveSettings();
    var opt = windowSelect.options[activeWindowIdx];
    if (opt) opt.textContent = escHtml(w.name)+" ("+w.start+" \u2013 "+w.end+")";
    renderResult();
    renderWindowsList();
  });

  /* ── manual override ──────────────────────────────────────── */
  manualToggle.addEventListener("change", function() {
    manualInputs.classList.toggle("visible", manualToggle.checked);
    noDataNotice.style.display = manualToggle.checked ? "none" : "";
    renderResult();
  });
  manualP.addEventListener("input", renderResult);
  manualA.addEventListener("input", renderResult);

  /* ── main render ──────────────────────────────────────────── */
  function renderAll() {
    syncMeta.textContent = scrapedAt ? "Last calculated: "+fmtTime(scrapedAt) : "";
    showWarnings(warnings);
    renderScheduleNotice();
    buildWindowSelect();

    var today   = todayStr();
    var wins    = settings.windows;
    var hasWin  = wins.length > 0;
    var allPast = hasWin && wins.every(function(w){ return w.end < today; });
    var showWin = hasWin && !allPast;

    noWindowNotice.style.display   = (!hasWin || allPast) ? "" : "none";
    windowSelect.style.display     = showWin ? "" : "none";
    // The end-date-edit wrapper
    var edWrap = quickEnd.parentElement;
    if (edWrap) edWrap.style.display = showWin ? "" : "none";

    var hasData  = !!attendance && Object.keys(attendance).length > 0;
    var manualOn = manualToggle.checked;
    noDataNotice.style.display = (!hasData && !manualOn) ? "" : "none";

    renderModeUI();
    renderUnposted();
    renderStrategyUI();
    renderResult();
    renderSimpleSchedule();
    renderLeavesCalendar();
    renderLeaveList();
    renderExamsCalendar();
    renderExamList();
    renderPrepList();
    renderHolidaysCalendar();
    renderHolidayList();
    renderLecturesGrid();
    targetInput.value = settings.target;
    if (pctLabel && (!attendance || Object.keys(attendance).length === 0)) {
      pctLabel.textContent = "--% / " + settings.target + "%";
    }
    renderWindowsList();
    updateGroupUI();
  }

  /* ── result card ──────────────────────────────────────────── */
  function renderResult() {
    clearError();
    var today    = todayStr();
    var wins     = settings.windows;
    var manualOn = manualToggle.checked;
    var hasData  = !!attendance && Object.keys(attendance).length > 0;

    if (!wins.length || wins.every(function(w){ return w.end < today; })) {
      resultCard.style.display = "none"; return;
    }
    if (!hasData && !manualOn) {
      resultCard.style.display = "none"; return;
    }

    var win = wins[activeWindowIdx] || wins[0];
    if (!win) { resultCard.style.display = "none"; return; }

    var att = manualOn ? buildManualAttendance(win, today) : (attendance || {});

    var res;
    try {
      res = computeSkips({
        attendance:         att,
        window:             win,
        today:              today,
        lecturesPerWeekday: settings.lecturesPerWeekday,
        holidays:           settings.holidays,
        plannedLeaves:      settings.plannedLeaves,
        examDays:           settings.examDays || [],
        prepLeaves:         settings.prepLeaves || [],
        target:             settings.target / 100,
        unposted:           settings.unposted,
        skipPreference:     settings.skipPreference || "max_days",
      });
    } catch(e) {
      showError("Calculation error: " + e.message);
      resultCard.style.display = "none"; return;
    }

    resultCard.style.display = "";

    // Headline (Google Pixel M3 Hero)
    resultHeadline.className = "result-headline";
    var stratWrap = resultHeadline.querySelector(".strategy-toggle-wrap");
    var hLabel = resultHeadline.querySelector(".h-label");

    if (res.mustAttendAll) {
      resultHeadline.classList.add("must-attend");
      if (stratWrap) stratWrap.style.display = "none";
      if (hBadgeRow) hBadgeRow.innerHTML = '<span class="h-lec-pill risky">\u26a0 0 lectures skippable</span>';
      if (res.leavesNeeded > 0) {
        var daysNeeded = Math.ceil(res.leavesNeeded / 6);
        if (hLabel) {
          hLabel.textContent = "ATTENDANCE ALERT \u2022 LEAVES REQUIRED";
          hLabel.style.color = "var(--status-risky-fg)";
        }
        if (hNum) {
          hNum.className = "h-num";
          hNum.style.color = "var(--status-risky-fg)";
          hNum.innerHTML = res.leavesNeeded + ' <span class="h-unit" style="color:var(--status-risky-fg)">Leaves Needed</span>';
        }
        if (hSub) {
          hSub.style.display = "";
          hSub.style.color = "#FFCDD2";
          hSub.textContent = "~" + daysNeeded + " day" + (daysNeeded !== 1 ? 's' : '') + ' of approved leaves required';
        }
        resultSub.innerHTML =
          'Even with 100% future attendance, max possible is <strong>' + res.maxPossiblePct.toFixed(1) + '%</strong>.<br>' +
          '<div class="leave-advice-card">' +
          '<span class="la-icon">\ud83d\udccb</span>' +
          '<span>Submit <strong>' + res.leavesNeeded + ' approved leaves</strong> (~' + daysNeeded + ' days) to college administration to reach <strong>' + settings.target + '%</strong>.</span>' +
          '</div>';
      } else {
        if (hLabel) {
          hLabel.textContent = "ATTENDANCE ALERT";
          hLabel.style.color = "";
        }
        if (hNum) {
          hNum.className = "h-num";
          hNum.style.color = "";
          hNum.innerHTML = "\u26a0 Attend All";
        }
        if (hSub) {
          hSub.style.display = "";
          hSub.style.color = "";
          hSub.textContent = 'Attend all ' + res.F + ' remaining lectures';
        }
        resultSub.innerHTML =
          'You\u2019re currently below the ' + settings.target + '% target.<br>' +
          'Attending all ' + res.F + ' remaining lectures will finish at <strong>' + res.maxPossiblePct.toFixed(1) + '%</strong>.';
      }
    } else if (res.fullDays === 0 && res.extraLectures === 0) {
      if (stratWrap) stratWrap.style.display = "none";
      if (hBadgeRow) hBadgeRow.innerHTML = '<span class="h-lec-pill">\u26a1 0 lectures skippable</span>';
      if (hLabel) {
        hLabel.textContent = "YOU CAN SAFELY MISS";
        hLabel.style.color = "";
      }
      if (hNum) {
        hNum.className = "h-num";
        hNum.style.color = "";
        hNum.innerHTML = '0 <span class="h-unit">days</span>';
      }
      if (hSub) {
        hSub.style.display = "";
        hSub.style.color = "";
        hSub.textContent = "No safe absences remain";
      }
      resultSub.textContent = "To complete the window at \u2265 " + settings.target + "% attendance.";
    } else {
      // Get all upcoming future school days in the window
      var holSet = new Set(settings.holidays);
      var lveSet = new Set(settings.plannedLeaves);
      var examSet = new Set(settings.examDays || []);
      var prepSet = new Set(settings.prepLeaves || []);
      var lecMap = settings.lecturesPerWeekday;
      var remFuture = [];
      function parseD(s){ var p=s.split("-").map(Number); return new Date(Date.UTC(p[0],p[1]-1,p[2])); }
      function fmtD(dt){ return dt.toISOString().slice(0,10); }
      function addD(s,n){ var dt=parseD(s); dt.setUTCDate(dt.getUTCDate()+n); return fmtD(dt); }
      var startRem;
      if (today < win.start) {
        startRem = win.start;
      } else if (res.dataThrough && res.dataThrough < today) {
        startRem = today;
      } else {
        startRem = addD(today, 1);
      }
      for (var d = startRem; d <= win.end; d = addD(d, 1)) {
        if (holSet.has(d) || lveSet.has(d) || prepSet.has(d)) continue;
        var w = parseD(d).getUTCDay();
        var isExam = examSet.has(d);
        var n = isExam ? 1 : (lecMap[w] || 0);
        if (n > 0) remFuture.push({ date: d, day: DAY_NAMES[w], lectures: n, isExam: isExam });
      }

      var skipDays = res.skipDays.slice();
      var extraLec = res.extraLectures;
      var pickedDates = new Set(skipDays.map(function(d){ return d.date; }));

      // Smart upgrade: if we have leftover extra lectures (e.g. +1) and lighter days (e.g. 5-lec Thursday),
      // absorb the extra lecture to convert the Thursday into a full standard day (6 lec)!
      // Only applicable in 'max_days' mode where lighter days were chosen first.
      if (settings.skipPreference !== "heavy_days" && extraLec > 0 && skipDays.length > 0) {
        var availableFullDays = remFuture.filter(function(d){
          return !pickedDates.has(d.date) && d.lectures === 6 && !d.isExam;
        });

        for (var i = skipDays.length - 1; i >= 0 && extraLec > 0; i--) {
          var d = skipDays[i];
          if (d.lectures < 6 && availableFullDays.length > 0) {
            var diff = 6 - d.lectures; // 1 for Thursday
            if (extraLec >= diff) {
              var fullDay = availableFullDays.shift();
              skipDays[i] = fullDay;
              extraLec -= diff;
              pickedDates.add(fullDay.date);
              pickedDates.delete(d.date);
            }
          }
        }
        skipDays.sort(function(a, b){ return a.date < b.date ? -1 : 1; });
      }

      // Smart exam allocation: if extra lectures remain and upcoming exam days exist (1 lecture each):
      // assign the extra lectures to exam days!
      if (extraLec > 0) {
        var availableExamDays = remFuture.filter(function(d){
          return d.isExam && !pickedDates.has(d.date);
        });
        while (extraLec >= 1 && availableExamDays.length > 0) {
          var examDay = availableExamDays.shift();
          skipDays.push(examDay);
          extraLec -= 1;
          pickedDates.add(examDay.date);
        }
        skipDays.sort(function(a, b){ return a.date < b.date ? -1 : 1; });
      }

      // Dynamic breakdown: distinguish standard 6-lecture days from lighter days and exam days
      var regularCount = 0;
      var examCount = 0;
      var specialMap = {};
      skipDays.forEach(function(d) {
        if (d.isExam) {
          examCount++;
        } else if (d.lectures === 6) {
          regularCount++;
        } else {
          var dayName = d.day === "Thu" ? "Thursday" :
                        d.day === "Fri" ? "Friday" :
                        d.day === "Wed" ? "Wednesday" :
                        d.day === "Tue" ? "Tuesday" :
                        d.day === "Mon" ? "Monday" :
                        d.day === "Sat" ? "Saturday" : d.day;
          specialMap[dayName] = (specialMap[dayName] || 0) + 1;
        }
      });

      var parts = [];
      if (regularCount > 0) {
        parts.push(regularCount + ' <span class="h-unit">day' + (regularCount !== 1 ? "s" : "") + '</span>');
      }
      Object.keys(specialMap).forEach(function(dayName) {
        var count = specialMap[dayName];
        parts.push(count + ' <span class="h-unit">' + dayName + (count !== 1 ? "s" : "") + '</span>');
      });
      if (examCount > 0) {
        parts.push(examCount + ' <span class="h-unit">exam day' + (examCount !== 1 ? "s" : "") + '</span>');
      }

      // Include extra flexible lectures in the headline breakdown
      if (extraLec > 0) {
        if (parts.length === 0) {
          parts.push(extraLec + ' <span class="h-unit">lecture' + (extraLec !== 1 ? "s" : "") + '</span>');
        } else {
          parts.push(extraLec + ' <span class="h-unit">extra lec</span>');
        }
      }

      var isBreakdown = parts.length > 1;
      var numHtml = parts.length > 0 ? parts.join(' <span class="h-unit">+</span> ') : (skipDays.length + ' <span class="h-unit">days</span>');
      var numClass = "h-num" + (isBreakdown ? " breakdown" : "");

      if (stratWrap) stratWrap.style.display = "flex";
      if (hLabel) {
        hLabel.textContent = "YOU CAN SAFELY MISS";
        hLabel.style.color = "";
      }
      if (hNum) {
        hNum.className = numClass;
        hNum.style.color = "";
        hNum.innerHTML = numHtml;
      }
      if (hSub) {
        hSub.style.display = "none";
        hSub.textContent = "";
      }

      if (hBadgeRow) {
        hBadgeRow.innerHTML =
          '<span class="h-lec-pill">\u26a1 ' + res.sMaxLectures + ' lectures skippable total</span>' +
          (res.finalPctIfMaxSkipped !== null ? '<span class="h-lec-pill secondary">\ud83c\udfaf ' + res.finalPctIfMaxSkipped.toFixed(1) + '% projected</span>' : '');
      }

      var fp = res.finalPctIfMaxSkipped !== null
               ? res.finalPctIfMaxSkipped.toFixed(1) : "\u2013";
      resultSub.textContent =
        "\u2026and still finish \u2265 " + settings.target + "% (projected: " + fp + "%)";
    }

    var status = getStatus(res, settings.target);
    if (res.mustAttendAll && res.leavesNeeded > 0) {
      status = "risky";
    }
    statusBadge.className = "status-badge " + status;
    resultCard.className  = "result-card " + status;
    statusText.textContent = (res.mustAttendAll && res.leavesNeeded > 0)
                           ? "\u2717 Leaves Needed"
                           : status === "safe" ? "\u2713 Safe"
                           : status === "tight" ? "~ Tight" : "\u2717 Risky";

    statP.textContent = res.P;
    statA.textContent = res.A;
    statL.textContent = res.L;
    statF.textContent = res.F;

    var pct = res.currentPct;
    var barCls = status === "risky" ? "risky" : status === "tight" ? "tight" : "";
    pctBar.className    = "pct-bar " + barCls;
    pctBar.style.width  = Math.min(100, pct) + "%";
    pctLabel.textContent = pct.toFixed(1) + "% / " + settings.target + "%";

    dataThrough.textContent = res.dataThrough
      ? "Data through " + fmtDate(res.dataThrough)
      : "No posted data yet";

    if (!res.mustAttendAll && skipDays && skipDays.length > 0) {
      skipSection.style.display = "";
      var st = "SUGGESTED ABSENCE DAYS";
      if (extraLec > 0) {
        st += " • +" + extraLec + " EXTRA LEC";
      }
      skipTitle.textContent = st;
      var chips = skipDays.map(function(d){
        var badge = d.isExam
          ? '<span class="sc-lec" style="background:var(--md-sys-color-primary-container);color:var(--md-sys-color-on-primary-container)">Exam • 1 lec</span>'
          : '<span class="sc-lec">' + d.lectures + ' lec</span>';
        return '<div class="skip-chip">'+
          '<span class="sc-date">' + fmtDate(d.date) + '</span>'+
          '<span class="sc-day">' + d.day + '</span>'+
          badge +
          '</div>';
      });
      if (extraLec > 0) {
        chips.push(
          '<div class="skip-chip" style="border-style:dashed">'+
          '<span class="sc-date">+' + extraLec + ' lec</span>'+
          '<span class="sc-day">Flexible</span>'+
          '<span class="sc-lec" style="background:var(--md-sys-color-surface-container-highest)">Part-day</span>'+
          '</div>'
        );
      }
      skipList.innerHTML = chips.join("");
    } else {
      skipSection.style.display = "none";
    }
  }

  function getStatus(res, target) {
    if (res.mustAttendAll) return "risky";
    // If they can skip 6 or more lectures (at least 1 full day cushion):
    if (res.sMaxLectures >= 6) return "safe";
    // If they have 1-5 lectures of cushion:
    if (res.sMaxLectures > 0) return "tight";
    // 0 safe lectures left:
    return "tight";
  }

  /* ── manual attendance builder ────────────────────────────── */
  function buildManualAttendance(win, today) {
    var Pn = Math.max(0, parseInt(manualP.value,10)||0);
    var An = Math.max(0, parseInt(manualA.value,10)||0);
    var att = {};
    var lec = settings.lecturesPerWeekday;
    var pRem=Pn, aRem=An;
    function parseD(s){ var p=s.split("-").map(Number); return new Date(Date.UTC(p[0],p[1]-1,p[2])); }
    function fmtD(dt){ return dt.toISOString().slice(0,10); }
    function addD(s,n){ var dt=parseD(s); dt.setUTCDate(dt.getUTCDate()+n); return fmtD(dt); }
    var d=win.start;
    while(d<=today && d<=win.end && (pRem>0||aRem>0)){
      var n=lec[parseD(d).getUTCDay()]||0;
      if(n===0){d=addD(d,1);continue;}
      if(pRem>0){
        var tp=Math.min(n,pRem);
        att[d]=Array(tp).fill("P"); pRem-=tp;
      } else {
        var ta=Math.min(n,aRem);
        att[d]=Array(ta).fill("A"); aRem-=ta;
      }
      d=addD(d,1);
    }
    return att;
  }

  /* ── unposted / pending portal sync days ────────────────────── */
  function renderUnposted() {
    if (!unpostedSection || !unpostedList) return;
    var today = todayStr();
    var wins  = settings.windows;
    if (!wins.length || !attendance) { unpostedSection.style.display = "none"; return; }
    var win = wins[activeWindowIdx] || wins[0];
    if (!win) { unpostedSection.style.display = "none"; return; }

    function parseD(s){ var p=s.split("-").map(Number); return new Date(Date.UTC(p[0],p[1]-1,p[2])); }
    function fmtD(dt){ return dt.toISOString().slice(0,10); }
    function addD(s,n){ var dt=parseD(s); dt.setUTCDate(dt.getUTCDate()+n); return fmtD(dt); }

    var holSet = new Set(settings.holidays || []);
    var prepSet = new Set(settings.prepLeaves || []);
    var examSet = new Set(settings.examDays || []);
    var lec = settings.lecturesPerWeekday;

    // Check all past days inside the active window up to today
    var rows = [];
    var d = win.start;
    while (d <= today && d <= win.end) {
      if (!holSet.has(d) && !prepSet.has(d)) {
        var isExam = examSet.has(d);
        var n = isExam ? 1 : (lec[parseD(d).getUTCDay()] || 0);
        if (n > 0 && (!attendance[d] || attendance[d].length === 0)) {
          rows.push({ date: d, isExam: isExam, lectures: n });
        }
      }
      d = addD(d, 1);
    }

    if (!rows.length) {
      unpostedSection.style.display = "none";
      return;
    }

    unpostedSection.style.display = "";
    unpostedList.innerHTML = rows.map(function(r) {
      var date = r.date;
      var cur = settings.unposted[date] || (r.isExam ? "PENDING" : "P");
      var day = DAY_NAMES[parseD(date).getUTCDay()];
      var badge = r.isExam
        ? '<span class="unposted-badge">📝 Exam Day (1 lec)</span>'
        : '<span class="unposted-badge" style="color:var(--md-sys-color-on-surface-variant)">Regular Day (' + r.lectures + ' lec)</span>';

      var optionsHtml = "";
      if (r.isExam) {
        optionsHtml =
          '<option value="PENDING"' + (cur === "PENDING" ? " selected" : "") + '>⏳ Portal didn\'t sync yet (Neutral)</option>' +
          '<option value="P"' + (cur === "P" ? " selected" : "") + '>✓ Attended Exam (1 lec)</option>' +
          '<option value="A"' + (cur === "A" ? " selected" : "") + '>✗ Missed Exam (1 lec)</option>';
      } else {
        optionsHtml =
          '<option value="PENDING"' + (cur === "PENDING" ? " selected" : "") + '>⏳ Portal didn\'t sync yet</option>' +
          '<option value="P"' + (cur === "P" ? " selected" : "") + '>✓ Attended (' + r.lectures + ' lec)</option>' +
          '<option value="A"' + (cur === "A" ? " selected" : "") + '>✗ Absent</option>' +
          '<option value="L"' + (cur === "L" ? " selected" : "") + '>🏖️ Approved Leave</option>';
      }

      return '<div class="unposted-item' + (r.isExam ? " exam-unposted" : "") + '" data-date="' + date + '">' +
        '<div class="unposted-info">' +
        badge +
        '<span class="date">' + fmtDate(date) + ' <span style="font-size:11px;opacity:0.7">(' + day + ')</span></span>' +
        '</div>' +
        '<select class="status-sel" data-date="' + date + '" aria-label="Status for ' + date + '">' +
        optionsHtml +
        '</select>' +
        '</div>';
    }).join("");

    unpostedList.querySelectorAll(".status-sel").forEach(function(sel) {
      sel.addEventListener("change", function() {
        settings.unposted[sel.dataset.date] = sel.value;
        saveSettings();
        renderResult();
      });
    });
  }

  /* ── generic calendar grid renderer ────────────────────────── */
  function renderCalendarGrid(gridEl, titleEl, year, month, type, selectedDates, onToggle, extraType, extraDates) {
    if (!gridEl || !titleEl) return;
    titleEl.textContent = FULL_MONTH_NAMES[month] + " " + year;
    gridEl.innerHTML = "";

    var daysInMonth = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
    var firstDow = new Date(Date.UTC(year, month, 1)).getUTCDay();
    // Monday = 0, Tuesday = 1, ..., Sunday = 6
    var offset = (firstDow + 6) % 7;

    for (var i = 0; i < offset; i++) {
      var emptyCell = document.createElement("div");
      emptyCell.className = "cal-day empty";
      gridEl.appendChild(emptyCell);
    }

    var today = todayStr();
    var set = new Set(selectedDates || []);
    var extraSet = extraDates ? new Set(extraDates) : null;

    for (var d = 1; d <= daysInMonth; d++) {
      var dStr = year + "-" + pad(month + 1) + "-" + pad(d);
      var isSel = set.has(dStr);
      var isExtra = extraSet && extraSet.has(dStr);
      var isToday = (dStr === today);
      var hasAtt = !!(attendance && attendance[dStr]);
      var isRecorded = (dStr < today && hasAtt);
      var isUnposted = (dStr < today && !hasAtt);

      var btn = document.createElement("button");
      btn.type = "button";
      var cls = "cal-day";
      if (isSel) cls += " selected " + type;
      else if (isExtra) cls += " selected " + extraType;

      if (isToday) cls += " today";
      if (isRecorded) cls += " recorded";
      if (isUnposted) cls += " unposted";
      btn.className = cls;
      btn.textContent = String(d);
      btn.dataset.date = dStr;
      btn.setAttribute("aria-label", dStr + (isSel ? " (" + type + ")" : (isExtra ? " (" + extraType + ")" : "")));

      (function(dateVal) {
        btn.addEventListener("click", function() {
          onToggle(dateVal);
        });
      })(dStr);

      gridEl.appendChild(btn);
    }
  }

  /* ── leaves ───────────────────────────────────────────────── */
  function renderLeavesCalendar() {
    renderCalendarGrid(
      calGridLeaves,
      calTitleLeaves,
      leavesCalYear,
      leavesCalMonth,
      "leave",
      settings.plannedLeaves,
      function(dateStr) {
        var idx = settings.plannedLeaves.indexOf(dateStr);
        if (idx === -1) {
          settings.plannedLeaves.push(dateStr);
          settings.plannedLeaves.sort();
        } else {
          settings.plannedLeaves.splice(idx, 1);
        }
        saveSettings();
        renderLeavesCalendar();
        renderLeaveList();
        renderResult();
      }
    );
  }

  if (calPrevLeaves) {
    calPrevLeaves.addEventListener("click", function() {
      leavesCalMonth--;
      if (leavesCalMonth < 0) { leavesCalMonth = 11; leavesCalYear--; }
      renderLeavesCalendar();
    });
  }
  if (calNextLeaves) {
    calNextLeaves.addEventListener("click", function() {
      leavesCalMonth++;
      if (leavesCalMonth > 11) { leavesCalMonth = 0; leavesCalYear++; }
      renderLeavesCalendar();
    });
  }

  function renderLeaveList() {
    if (!leaveList) return;
    if (!settings.plannedLeaves.length) {
      leaveList.innerHTML = '<p style="font-size:11.5px;color:var(--md-sys-color-on-surface-variant);padding:4px 0">No leaves selected. Tap dates on the calendar above.</p>';
      return;
    }
    leaveList.innerHTML = settings.plannedLeaves.map(function(date) {
      return '<div class="leave-item">' +
        '<span class="date">' + fmtDate(date) + '</span>' +
        '<span class="day-lbl">' + DAY_NAMES[weekdayOf(date)] + '</span>' +
        '<button class="del-btn" data-date="' + date + '" aria-label="Remove ' + date + '">&#215;</button>' +
        '</div>';
    }).join("");
    leaveList.querySelectorAll(".del-btn").forEach(function(btn) {
      btn.addEventListener("click", function() {
        settings.plannedLeaves = settings.plannedLeaves.filter(function(d) { return d !== btn.dataset.date; });
        saveSettings();
        renderLeavesCalendar();
        renderLeaveList();
        renderResult();
      });
    });
  }

  /* ── lectures grid ────────────────────────────────────────── */
  function renderLecturesGrid() {
    var hdrs=DAY_NAMES.map(function(n){return '<div class="day-hdr">'+n+'</div>';}).join("");
    var inps=DAY_NAMES.map(function(_,i){
      return '<input type="number" min="0" max="20" id="lec-'+i+
             '" value="'+(settings.lecturesPerWeekday[i]||0)+
             '" aria-label="'+DAY_NAMES[i]+' lectures" />';
    }).join("");
    lecturesGrid.innerHTML=hdrs+inps;
    DAY_NAMES.forEach(function(_,i){
      var inp=$$("lec-"+i);
      if(!inp) return;
      inp.addEventListener("input",function(){
        settings.lecturesPerWeekday[i]=Math.max(0,parseInt(inp.value,10)||0);
        saveSettings(); renderResult();
      });
    });
  }

  /* ── strategy preference ───────────────────────────────────── */
  function renderStrategyUI() {
    var strat = settings.skipPreference || "max_days";
    if (btnStratMaxDays && btnStratHeavy) {
      if (strat === "heavy_days") {
        btnStratHeavy.classList.add("active");
        btnStratMaxDays.classList.remove("active");
      } else {
        btnStratMaxDays.classList.add("active");
        btnStratHeavy.classList.remove("active");
      }
    }
    if (radioStratMaxDays && radioStratHeavy) {
      if (strat === "heavy_days") {
        radioStratHeavy.checked = true;
      } else {
        radioStratMaxDays.checked = true;
      }
    }
  }

  function setSkipPreference(strat) {
    if (strat !== "max_days" && strat !== "heavy_days") strat = "max_days";
    settings.skipPreference = strat;
    saveSettings();
    renderStrategyUI();
    renderResult();
  }

  if (btnStratMaxDays) {
    btnStratMaxDays.addEventListener("click", function() {
      setSkipPreference("max_days");
    });
  }
  if (btnStratHeavy) {
    btnStratHeavy.addEventListener("click", function() {
      setSkipPreference("heavy_days");
    });
  }
  if (radioStratMaxDays) {
    radioStratMaxDays.addEventListener("change", function() {
      if (radioStratMaxDays.checked) setSkipPreference("max_days");
    });
  }
  if (radioStratHeavy) {
    radioStratHeavy.addEventListener("change", function() {
      if (radioStratHeavy.checked) setSkipPreference("heavy_days");
    });
  }

  /* ── Simple / Advanced Mode (Segmented Control) ─────────────── */
  function renderModeUI() {
    var isSimple = (settings.simpleMode !== undefined) ? !!settings.simpleMode : true;
    document.body.classList.toggle("simple-mode", isSimple);
    if (btnModeSimple) {
      btnModeSimple.classList.toggle("active", isSimple);
    }
    if (btnModeAdvanced) {
      btnModeAdvanced.classList.toggle("active", !isSimple);
    }
    // If in Simple mode, ensure panel-main is active
    if (isSimple) {
      panels.forEach(function(p){ p.classList.remove("active"); });
      var pm = $$("panel-main");
      if (pm) pm.classList.add("active");
      tabBtns.forEach(function(b){ b.classList.remove("active"); });
      var tm = $$("tab-main");
      if (tm) tm.classList.add("active");
    }
  }

  function setSimpleMode(enableSimple) {
    if (settings.simpleMode === enableSimple) return;
    settings.simpleMode = enableSimple;
    saveSettings();
    renderModeUI();
    renderAll();
  }

  if (btnModeSimple) {
    btnModeSimple.addEventListener("click", function() {
      setSimpleMode(true);
    });
  }
  if (btnModeAdvanced) {
    btnModeAdvanced.addEventListener("click", function() {
      setSimpleMode(false);
    });
  }

  /* ── Simple Mode Schedule Overview ─────────────────────────── */
  function renderSimpleSchedule() {
    if (!simpleScheduleCard) return;

    if (simpleSchedGroupTag) {
      simpleSchedGroupTag.textContent = settings.groupCode ? "Section " + settings.groupCode : "";
    }

    var holList = (settings.holidays || []).slice().sort();
    var examList = (settings.examDays || []).slice().sort();
    var prepList = (settings.prepLeaves || []).slice().sort();
    var today = todayStr();

    function makeChips(dates, typeClass, labelSuffix) {
      if (!dates || !dates.length) return '<div class="ss-empty">None scheduled</div>';
      return dates.map(function(d) {
        var isPast = d < today;
        var dayName = DAY_NAMES[weekdayOf(d)] || "";
        var style = isPast ? 'opacity:0.4;text-decoration:line-through' : '';
        return '<div class="ss-chip ' + typeClass + '" style="' + style + '">' +
          '<span class="ss-date">' + fmtDate(d) + '</span>' +
          '<span class="ss-day">' + dayName + (labelSuffix ? " • " + labelSuffix : "") + '</span>' +
          '</div>';
      }).join("");
    }

    if (simpleExamsList) simpleExamsList.innerHTML = makeChips(examList, "exam", "1 lec");
    if (simplePrepList) simplePrepList.innerHTML = makeChips(prepList, "prep", "0 lec");
    if (simpleHolidaysList) simpleHolidaysList.innerHTML = makeChips(holList, "holiday", "Off");
  }

  /* ── developer authorization check ─────────────────────────── */
  function isDevUser() {
    if (settings.isDevMode) return true;
    if (!settings.groupUsername) return false;
    var u = cleanUsername(settings.groupUsername).toLowerCase();
    return u === "cola" || u.indexOf("cola") === 0 || u === "colaup747";
  }

  /* ── target ───────────────────────────────────────────────── */
  targetInput.addEventListener("input", function() {
    var v=Math.min(100,Math.max(1,parseInt(targetInput.value,10)||80));
    settings.target=v; saveSettings(); renderResult();
  });

  /* ── holidays ─────────────────────────────────────────────── */
  function renderHolidaysCalendar() {
    if (!settings.holidays) settings.holidays = [];
    renderCalendarGrid(
      calGridHolidays,
      calTitleHolidays,
      holidaysCalYear,
      holidaysCalMonth,
      "holiday",
      settings.holidays,
      function(dateStr) {
        var idx = settings.holidays.indexOf(dateStr);
        if (idx === -1) {
          settings.holidays.push(dateStr);
          settings.holidays.sort();
        } else {
          settings.holidays.splice(idx, 1);
        }
        saveSettings();
        renderHolidaysCalendar();
        renderHolidayList();
        renderResult();
      }
    );
  }

  if (calPrevHolidays) {
    calPrevHolidays.addEventListener("click", function() {
      holidaysCalMonth--;
      if (holidaysCalMonth < 0) { holidaysCalMonth = 11; holidaysCalYear--; }
      renderHolidaysCalendar();
    });
  }
  if (calNextHolidays) {
    calNextHolidays.addEventListener("click", function() {
      holidaysCalMonth++;
      if (holidaysCalMonth > 11) { holidaysCalMonth = 0; holidaysCalYear++; }
      renderHolidaysCalendar();
    });
  }

  function renderHolidayList() {
    if (!holidayList) return;
    if (!settings.holidays.length) {
      holidayList.innerHTML = '<p style="font-size:11.5px;color:var(--md-sys-color-on-surface-variant);padding:4px 0">No holidays added. Tap dates on the calendar above.</p>';
      return;
    }
    holidayList.innerHTML = settings.holidays.map(function(date) {
      return '<div class="holiday-item">' +
        '<span class="date">' + fmtDate(date) +
        ' <span style="color:var(--md-sys-color-on-surface-variant);font-size:10px">' + DAY_NAMES[weekdayOf(date)] + '</span></span>' +
        '<button class="del-btn" data-date="' + date + '" aria-label="Remove holiday ' + date + '">&#215;</button>' +
        '</div>';
    }).join("");
    holidayList.querySelectorAll(".del-btn").forEach(function(btn) {
      btn.addEventListener("click", function() {
        hasLocalEdits = true;
        settings.holidays = settings.holidays.filter(function(d) { return d !== btn.dataset.date; });
        saveSettings();
        renderHolidaysCalendar();
        renderHolidayList();
        renderResult();
      });
    });
  }

  /* ── exams & prep offs ────────────────────────────────────── */
  function renderExamsCalendar() {
    if (!settings.examDays) settings.examDays = [];
    if (!settings.prepLeaves) settings.prepLeaves = [];

    renderCalendarGrid(
      calGridExams,
      calTitleExams,
      examsCalYear,
      examsCalMonth,
      "exam",
      settings.examDays,
      function(dateStr) {
        hasLocalEdits = true;
        if (examsCloudStatus) {
          examsCloudStatus.style.display = "block";
          examsCloudStatus.style.background = "rgba(255,255,255,0.05)";
          examsCloudStatus.style.color = "var(--md-sys-color-primary)";
          examsCloudStatus.textContent = "● You have unsaved changes. Tap 'Save Changes to Cloud' to sync.";
        }
        if (examEditMode === "exam") {
          var idx = settings.examDays.indexOf(dateStr);
          if (idx === -1) {
            settings.examDays.push(dateStr);
            settings.examDays.sort();
            settings.prepLeaves = settings.prepLeaves.filter(function(d){ return d !== dateStr; });
          } else {
            settings.examDays.splice(idx, 1);
          }
        } else {
          var pIdx = settings.prepLeaves.indexOf(dateStr);
          if (pIdx === -1) {
            settings.prepLeaves.push(dateStr);
            settings.prepLeaves.sort();
            settings.examDays = settings.examDays.filter(function(d){ return d !== dateStr; });
          } else {
            settings.prepLeaves.splice(pIdx, 1);
          }
        }
        saveSettings();
        renderExamsCalendar();
        renderExamList();
        renderPrepList();
        renderUnposted();
        renderResult();
      },
      "prep",
      settings.prepLeaves
    );
  }

  if (calPrevExams) {
    calPrevExams.addEventListener("click", function() {
      examsCalMonth--;
      if (examsCalMonth < 0) { examsCalMonth = 11; examsCalYear--; }
      renderExamsCalendar();
    });
  }
  if (calNextExams) {
    calNextExams.addEventListener("click", function() {
      examsCalMonth++;
      if (examsCalMonth > 11) { examsCalMonth = 0; examsCalYear++; }
      renderExamsCalendar();
    });
  }

  if (btnModeExam) {
    btnModeExam.addEventListener("click", function() {
      examEditMode = "exam";
      btnModeExam.classList.add("active");
      if (btnModePrep) btnModePrep.classList.remove("active");
    });
  }
  if (btnModePrep) {
    btnModePrep.addEventListener("click", function() {
      examEditMode = "prep";
      btnModePrep.classList.add("active");
      if (btnModeExam) btnModeExam.classList.remove("active");
    });
  }

  if (btnAutofillPrep) {
    btnAutofillPrep.addEventListener("click", function() {
      var exams = (settings.examDays || []).slice().sort();
      if (exams.length < 2) {
        showError("Please select at least 2 exam dates on the calendar first to auto-fill offs between them.");
        return;
      }
      var first = exams[0];
      var last = exams[exams.length - 1];
      var holSet = new Set(settings.holidays || []);
      var examSet = new Set(exams);
      var prepSet = new Set(settings.prepLeaves || []);
      var added = 0;

      function parseD(s){ var p=s.split("-").map(Number); return new Date(Date.UTC(p[0],p[1]-1,p[2])); }
      function fmtD(dt){ return dt.toISOString().slice(0,10); }
      function addD(s,n){ var dt=parseD(s); dt.setUTCDate(dt.getUTCDate()+n); return fmtD(dt); }

      for (var d = addD(first, 1); d < last; d = addD(d, 1)) {
        var dow = parseD(d).getUTCDay();
        if (dow !== 0 && !examSet.has(d) && !holSet.has(d)) {
          if (!prepSet.has(d)) {
            prepSet.add(d);
            added++;
          }
        }
      }
      hasLocalEdits = true;
      if (examsCloudStatus) {
        examsCloudStatus.style.display = "block";
        examsCloudStatus.style.background = "rgba(255,255,255,0.05)";
        examsCloudStatus.style.color = "var(--md-sys-color-primary)";
        examsCloudStatus.textContent = "● You have unsaved changes. Tap 'Save Changes to Cloud' to sync.";
      }
      settings.prepLeaves = Array.from(prepSet).sort();
      saveSettings();
      renderExamsCalendar();
      renderPrepList();
      renderResult();
      if (added > 0) {
        showWarnings(["Auto-filled " + added + " prep off day(s) between exams."]);
      }
    });
  }

  function renderExamList() {
    if (!examList) return;
    var list = settings.examDays || [];
    if (!list.length) {
      examList.innerHTML = '<p style="font-size:11.5px;color:var(--md-sys-color-on-surface-variant);padding:4px 0">No exam dates selected. Tap dates on the calendar above.</p>';
      return;
    }
    examList.innerHTML = list.map(function(date) {
      return '<div class="holiday-item">' +
        '<span class="date">' + fmtDate(date) +
        ' <span style="color:var(--md-sys-color-on-surface-variant);font-size:10px">' + DAY_NAMES[weekdayOf(date)] + ' (1 lec)</span></span>' +
        '<button class="del-btn" data-date="' + date + '" aria-label="Remove exam ' + date + '">&#215;</button>' +
        '</div>';
    }).join("");
    examList.querySelectorAll(".del-btn").forEach(function(btn) {
      btn.addEventListener("click", function() {
        hasLocalEdits = true;
        settings.examDays = settings.examDays.filter(function(d) { return d !== btn.dataset.date; });
        saveSettings();
        renderExamsCalendar();
        renderExamList();
        renderUnposted();
        renderResult();
      });
    });
  }

  function renderPrepList() {
    if (!prepList) return;
    var list = settings.prepLeaves || [];
    if (!list.length) {
      prepList.innerHTML = '<p style="font-size:11.5px;color:var(--md-sys-color-on-surface-variant);padding:4px 0">No prep offs added. Click "Prep Offs (0 lec)" mode or tap "Auto-Fill".</p>';
      return;
    }
    prepList.innerHTML = list.map(function(date) {
      return '<div class="holiday-item" style="border-color:rgba(77,208,225,0.25)">' +
        '<span class="date">' + fmtDate(date) +
        ' <span style="color:#80DEEA;font-size:10px">' + DAY_NAMES[weekdayOf(date)] + ' (0 lec • Study Off)</span></span>' +
        '<button class="del-btn" data-date="' + date + '" aria-label="Remove prep off ' + date + '">&#215;</button>' +
        '</div>';
    }).join("");
    prepList.querySelectorAll(".del-btn").forEach(function(btn) {
      btn.addEventListener("click", function() {
        hasLocalEdits = true;
        settings.prepLeaves = settings.prepLeaves.filter(function(d) { return d !== btn.dataset.date; });
        saveSettings();
        renderExamsCalendar();
        renderPrepList();
        renderUnposted();
        renderResult();
      });
    });
  }

  /* ── Firebase Group Cloud Sync & RBAC Permissions ─────────── */
  var DEFAULT_FIREBASE_URL = "https://pgc-attendance-cloud-default-rtdb.asia-southeast1.firebasedatabase.app";

  function getFirebaseBaseUrl() {
    var custom = (settings && settings.customFirebaseUrl || "").trim();
    if (custom) return custom.replace(/\/+$/, "");
    return DEFAULT_FIREBASE_URL;
  }

  function cleanGroupCode(code) {
    return String(code || "").trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "_");
  }

  function cleanUsername(name) {
    return String(name || "").trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
  }

  function hashPin(pin) {
    var str = String(pin || "").trim();
    if (!str) return Promise.resolve("");
    return crypto.subtle.digest("SHA-256", new TextEncoder().encode(str)).then(function(buf) {
      return Array.from(new Uint8Array(buf)).map(function(b) {
        return b.toString(16).padStart(2, "0");
      }).join("");
    });
  }

  function updateGroupUI() {
    if (groupCodeInput && settings.groupCode) {
      groupCodeInput.value = settings.groupCode;
    }
    if (groupUsernameInput && settings.groupUsername) {
      groupUsernameInput.value = settings.groupUsername;
    }
    if (customFbUrlInput) {
      customFbUrlInput.value = settings.customFirebaseUrl || "";
    }
    if (groupAutosyncToggle) {
      groupAutosyncToggle.checked = settings.groupAutoSync !== false;
    }

    var isLoggedIn = !!(settings.groupCode && settings.groupUsername && settings.groupPinHash);

    if (groupAuthBlock) {
      groupAuthBlock.style.display = isLoggedIn ? "none" : "";
    }
    if (groupBtnGrid) {
      groupBtnGrid.style.display = isLoggedIn ? "flex" : "none";
    }
    if (btnLogoutGroup) {
      btnLogoutGroup.style.display = isLoggedIn ? "inline-block" : "none";
    }

    if (userRoleBadge) {
      var role = (settings.groupUserRole || "").toLowerCase();
      if (!isLoggedIn) {
        userRoleBadge.className = "user-badge";
        userRoleBadge.textContent = "Not Logged In";
      } else if (role === "admin") {
        userRoleBadge.className = "user-badge admin";
        userRoleBadge.textContent = "👑 Admin";
      } else if (role === "editor") {
        userRoleBadge.className = "user-badge editor";
        userRoleBadge.textContent = "✏️ Editor";
      } else {
        userRoleBadge.className = "user-badge viewer";
        userRoleBadge.textContent = "👁️ Student";
      }
    }

    var isAdmin = isLoggedIn && (settings.groupUserRole === "admin");
    if (adminActionsWrap) {
      adminActionsWrap.style.display = isAdmin ? "block" : "none";
    }
    if (adminOtaPanel) {
      adminOtaPanel.style.display = (isAdmin && isDevUser()) ? "block" : "none";
    }
    if (!isAdmin && adminPermSection) {
      adminPermSection.style.display = "none";
    }

    if (groupStatus) {
      if (isLoggedIn) {
        groupStatus.className = "group-status success";
        var syncNote = settings.groupLastSync ? " \u2022 Synced " + fmtTime(settings.groupLastSync) : "";
        var roleLabel = settings.groupUserRole === "admin" ? "Admin" :
                        settings.groupUserRole === "editor" ? "Editor" : "Student";
        groupStatus.textContent = "\u2713 Logged in as " + settings.groupUsername + " (" + roleLabel + ") in " + settings.groupCode + syncNote;
      } else {
        groupStatus.className = "group-status";
        groupStatus.textContent = "Enter group code, your name, and PIN to log in or register.";
      }
    }
  }

  // Collapsible Firebase URL Config Toggle
  if (fbConfigToggleBtn) {
    fbConfigToggleBtn.addEventListener("click", function() {
      var isHidden = !fbConfigBody || fbConfigBody.style.display === "none";
      if (fbConfigBody) fbConfigBody.style.display = isHidden ? "block" : "none";
      if (fbConfigArrow) fbConfigArrow.textContent = isHidden ? "▾" : "▸";
    });
  }

  if (customFbUrlInput) {
    customFbUrlInput.addEventListener("change", function() {
      settings.customFirebaseUrl = customFbUrlInput.value.trim();
      saveSettings();
      testDatabaseConnection();
    });
  }

  if (groupAutosyncToggle) {
    groupAutosyncToggle.addEventListener("change", function() {
      settings.groupAutoSync = groupAutosyncToggle.checked;
      saveSettings();
    });
  }

  // Logout Handler
  if (btnLogoutGroup) {
    btnLogoutGroup.addEventListener("click", function() {
      settings.groupCode = "";
      settings.groupUsername = "";
      settings.groupPinHash = "";
      settings.groupUserRole = "";
      settings.groupPermissions = null;
      if (groupPinInput) groupPinInput.value = "";
      saveSettings();
      updateGroupUI();
    });
  }

  // Tab switcher: Join vs Create Group
  if (tabAuthJoin && tabAuthCreate) {
    tabAuthJoin.addEventListener("click", function() {
      tabAuthJoin.classList.add("active");
      tabAuthCreate.classList.remove("active");
      if (authPanelJoin) authPanelJoin.style.display = "";
      if (authPanelCreate) authPanelCreate.style.display = "none";
      if (groupStatus) {
        groupStatus.className = "group-status";
        groupStatus.textContent = "Enter your section code, username, and PIN to join.";
      }
    });
    tabAuthCreate.addEventListener("click", function() {
      tabAuthCreate.classList.add("active");
      tabAuthJoin.classList.remove("active");
      if (authPanelCreate) authPanelCreate.style.display = "";
      if (authPanelJoin) authPanelJoin.style.display = "none";
      if (groupStatus) {
        groupStatus.className = "group-status";
        groupStatus.textContent = "Enter a section code to create a new group as Admin.";
      }
    });
  }

  // 1. Join Existing Group Handler
  if (btnGroupLogin) {
    btnGroupLogin.addEventListener("click", function() {
      clearError();
      var rawCode = (groupCodeInput ? groupCodeInput.value : "").trim();
      var rawName = (groupUsernameInput ? groupUsernameInput.value : "").trim();
      var rawPin  = (groupPinInput ? groupPinInput.value : "").trim();

      var code = cleanGroupCode(rawCode);
      var userKey = cleanUsername(rawName);

      if (!code) { showError("Please enter your Section Group Code (e.g. ICS-2A)."); return; }
      if (!rawName || !userKey) { showError("Please enter your Name or Roll No."); return; }
      if (!rawPin || rawPin.length < 3) { showError("Please enter a PIN (at least 3 characters)."); return; }

      hashPin(rawPin).then(function(pinHash) {
        if (groupStatus) {
          groupStatus.className = "group-status";
          groupStatus.textContent = "Searching for section " + code + "\u2026";
        }

        var baseUrl = getFirebaseBaseUrl();
        var url = baseUrl + "/groups/" + encodeURIComponent(code) + ".json";

        fetch(url).then(function(res) {
          if (!res.ok) throw new Error("HTTP " + res.status + " – Check Firebase database URL & permissions.");
          return res.json();
        }).then(function(groupData) {
          // If group does not exist: alert student so they don't get lost
          if (!groupData || !groupData.members) {
            throw new Error("Section group '" + code + "' was not found. Please verify the code with your Class Representative, or switch to 'Create New Group' if you are setting it up for your class.");
          }

          var members = groupData.members || {};
          var existingMember = members[userKey];

          if (existingMember) {
            // Member username already exists -> Verify PIN!
            if (existingMember.pinHash !== pinHash) {
              throw new Error("Incorrect PIN for '" + rawName + "'. If this is your account, enter your correct PIN. If you are a new member, choose a different username.");
            }
            // PIN verified!
            settings.groupCode = code;
            settings.groupUsername = existingMember.name || rawName;
            settings.groupPinHash = pinHash;
            settings.groupUserRole = existingMember.role || "viewer";
            settings.groupPermissions = existingMember.permissions || {
              canEditExams: existingMember.role !== "viewer",
              canEditHolidays: existingMember.role !== "viewer",
              canEditWindows: existingMember.role === "admin",
              canEditLectures: existingMember.role === "admin",
              canManageMembers: existingMember.role === "admin"
            };
          } else {
            // New member registration in existing group:
            var defaultRole = "viewer";
            var defaultPerms = {
              canEditExams: false,
              canEditHolidays: false,
              canEditWindows: false,
              canEditLectures: false,
              canManageMembers: false
            };

            var regMember = {
              name: rawName,
              username: rawName,
              pinHash: pinHash,
              role: defaultRole,
              permissions: defaultPerms,
              joinedAt: new Date().toISOString()
            };

            var memUrl = baseUrl + "/groups/" + encodeURIComponent(code) + "/members/" + encodeURIComponent(userKey) + ".json";
            fetch(memUrl, {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(regMember)
            });

            settings.groupCode = code;
            settings.groupUsername = rawName;
            settings.groupPinHash = pinHash;
            settings.groupUserRole = defaultRole;
            settings.groupPermissions = defaultPerms;
          }

          // Pull group's shared schedule:
          if (groupData.schedule) {
            var s = groupData.schedule;
            if (s.examDays)   settings.examDays = s.examDays;
            if (s.prepLeaves) settings.prepLeaves = s.prepLeaves;
            if (s.holidays)   settings.holidays = s.holidays;
            if (s.windows && s.windows.length) settings.windows = s.windows;
            if (s.target)     settings.target = s.target;
            if (s.lecturesPerWeekday) settings.lecturesPerWeekday = s.lecturesPerWeekday;
          }

          settings.groupLastSync = new Date().toISOString();
          saveSettings();
          renderAll();
          if (groupPinInput) groupPinInput.value = "";
          updateGroupUI();
          if (groupStatus) {
            groupStatus.className = "group-status success";
            groupStatus.textContent = "\u2713 Connected to section " + code + "! Shared schedule synced.";
          }
        }).catch(function(err) {
          showError(err.message);
          if (groupStatus) {
            groupStatus.className = "group-status";
            groupStatus.textContent = "Join failed: " + err.message;
          }
        });
      });
    });
  }

  // 2. Create New Group Handler (For Admins / CRs)
  if (btnGroupCreate) {
    btnGroupCreate.addEventListener("click", function() {
      clearError();
      var rawCode = (createGroupCodeInput ? createGroupCodeInput.value : "").trim();
      var rawName = (createGroupUsernameInput ? createGroupUsernameInput.value : "").trim();
      var rawPin  = (createGroupPinInput ? createGroupPinInput.value : "").trim();

      var code = cleanGroupCode(rawCode);
      var userKey = cleanUsername(rawName);

      if (!code) { showError("Please enter a New Section Code (e.g. ICS-2A)."); return; }
      if (!rawName || !userKey) { showError("Please enter your Name or Roll No."); return; }
      if (!rawPin || rawPin.length < 3) { showError("Please enter an Admin PIN (at least 3 characters)."); return; }

      hashPin(rawPin).then(function(pinHash) {
        if (groupStatus) {
          groupStatus.className = "group-status";
          groupStatus.textContent = "Checking group availability\u2026";
        }

        var baseUrl = getFirebaseBaseUrl();
        var url = baseUrl + "/groups/" + encodeURIComponent(code) + ".json";

        fetch(url).then(function(res) {
          if (!res.ok) throw new Error("HTTP " + res.status + " – Check Firebase database URL & permissions.");
          return res.json();
        }).then(function(groupData) {
          // If group already exists, forbid accidental overwriting!
          if (groupData && groupData.members) {
            throw new Error("Group '" + code + "' already exists! If you are the Class Rep or a member of this section, switch to 'Join Section Group' to log in.");
          }

          var adminPermissions = {
            canEditExams: true,
            canEditHolidays: true,
            canEditWindows: true,
            canEditLectures: true,
            canManageMembers: true
          };

          var newMember = {
            name: rawName,
            username: rawName,
            pinHash: pinHash,
            role: "admin",
            permissions: adminPermissions,
            joinedAt: new Date().toISOString()
          };

          var initialSchedule = {
            examDays:   settings.examDays || [],
            prepLeaves: settings.prepLeaves || [],
            holidays:   settings.holidays || [],
            windows:    settings.windows || [],
            lecturesPerWeekday: settings.lecturesPerWeekday,
            target:     settings.target || 80,
            updatedAt:  new Date().toISOString(),
            updatedBy:  rawName
          };

          var initialPayload = {
            meta: {
              groupCode: code,
              createdBy: rawName,
              createdAt: new Date().toISOString()
            },
            members: {},
            schedule: initialSchedule
          };
          initialPayload.members[userKey] = newMember;

          return fetch(url, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(initialPayload)
          }).then(function(putRes) {
            if (!putRes.ok) throw new Error("Failed to create group in cloud.");
            settings.groupCode = code;
            settings.groupUsername = rawName;
            settings.groupPinHash = pinHash;
            settings.groupUserRole = "admin";
            settings.groupPermissions = adminPermissions;
            settings.groupLastSync = new Date().toISOString();
            saveSettings();
            updateGroupUI();
            if (createGroupPinInput) createGroupPinInput.value = "";
            if (groupStatus) {
              groupStatus.className = "group-status success";
              groupStatus.textContent = "\u2713 Created section " + code + "! You are the Admin. Share this code with your classmates.";
            }
          });
        }).catch(function(err) {
          showError(err.message);
          if (groupStatus) {
            groupStatus.className = "group-status";
            groupStatus.textContent = "Creation failed: " + err.message;
          }
        });
      });
    });
  }

  // Reusable Cloud Publish Function (used by Settings & Exams tab)
  function publishScheduleToCloud(statusEl) {
    clearError();
    if (!settings.groupCode || !settings.groupUsername) {
      var msg = "Please log in or join a group in Settings first.";
      if (statusEl) {
        if (statusEl === groupStatus) {
          statusEl.className = "group-status error";
          statusEl.textContent = msg;
        } else {
          statusEl.style.display = "block";
          statusEl.style.color = "var(--status-risky-fg)";
          statusEl.textContent = "⚠️ " + msg;
        }
      }
      showError(msg);
      return;
    }
    var code = settings.groupCode;
    var userKey = cleanUsername(settings.groupUsername);
    var baseUrl = getFirebaseBaseUrl();

    if (statusEl) {
      if (statusEl === groupStatus) {
        statusEl.className = "group-status";
        statusEl.textContent = "Verifying permissions & publishing\u2026";
      } else {
        statusEl.style.display = "block";
        statusEl.style.color = "var(--md-sys-color-primary)";
        statusEl.textContent = "Publishing changes to group " + code + "\u2026";
      }
    }

    // Re-fetch member record from cloud to guarantee latest permissions
    var memUrl = baseUrl + "/groups/" + encodeURIComponent(code) + "/members/" + encodeURIComponent(userKey) + ".json";
    fetch(memUrl).then(function(mRes) {
      if (!mRes.ok) throw new Error("Could not verify permissions from cloud.");
      return mRes.json();
    }).then(function(liveMember) {
      if (liveMember) {
        settings.groupUserRole = liveMember.role || settings.groupUserRole;
        settings.groupPermissions = liveMember.permissions || settings.groupPermissions;
        saveSettings();
        updateGroupUI();
      }

      var role = (settings.groupUserRole || "").toLowerCase();
      var perms = settings.groupPermissions || {};

      // Fetch current cloud schedule to check which sections were modified
      var schedUrl = baseUrl + "/groups/" + encodeURIComponent(code) + "/schedule.json";
      return fetch(schedUrl).then(function(sRes) {
        if (!sRes.ok) throw new Error("Could not fetch current cloud schedule.");
        return sRes.json();
      }).then(function(cloudSched) {
        cloudSched = cloudSched || {};

        // 1. Check Window Cutoff Dates Permission:
        var curWinStr = JSON.stringify(settings.windows || []);
        var cloudWinStr = JSON.stringify(cloudSched.windows || []);
        if (curWinStr !== cloudWinStr && role !== "admin" && perms.canEditWindows === false) {
          throw new Error("⛔ Permission Denied: Admin has restricted you from modifying Fee-Installment Window cutoff dates.");
        }

        // 2. Check Exam Dates & Prep Offs Permission:
        var curExamStr = JSON.stringify((settings.examDays || []).slice().sort()) + JSON.stringify((settings.prepLeaves || []).slice().sort());
        var cloudExamStr = JSON.stringify((cloudSched.examDays || []).slice().sort()) + JSON.stringify((cloudSched.prepLeaves || []).slice().sort());
        if (curExamStr !== cloudExamStr && role !== "admin" && perms.canEditExams === false) {
          throw new Error("⛔ Permission Denied: You do not have permission to modify exam dates or prep offs.");
        }

        // 3. Check Official Holidays Permission:
        var curHolStr = JSON.stringify((settings.holidays || []).slice().sort());
        var cloudHolStr = JSON.stringify((cloudSched.holidays || []).slice().sort());
        if (curHolStr !== cloudHolStr && role !== "admin" && perms.canEditHolidays === false) {
          throw new Error("⛔ Permission Denied: You do not have permission to modify official holidays.");
        }

        // 4. Check Daily Lecture Counts Permission:
        var curLecStr = JSON.stringify(settings.lecturesPerWeekday || {});
        var cloudLecStr = JSON.stringify(cloudSched.lecturesPerWeekday || {});
        if (curLecStr !== cloudLecStr && role !== "admin" && perms.canEditLectures === false) {
          throw new Error("⛔ Permission Denied: You do not have permission to modify daily lecture counts.");
        }

        // All permission checks passed! Build payload and publish:
        var payload = {
          examDays:   settings.examDays || [],
          prepLeaves: settings.prepLeaves || [],
          holidays:   settings.holidays || [],
          windows:    settings.windows || [],
          lecturesPerWeekday: settings.lecturesPerWeekday,
          target:     settings.target || 80,
          updatedAt:  new Date().toISOString(),
          updatedBy:  settings.groupUsername
        };

        return fetch(schedUrl, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        }).then(function(putRes) {
          if (!putRes.ok) throw new Error("Failed to update cloud schedule.");
          settings.groupLastSync = new Date().toISOString();
          settings.lastAckedScheduleUpdate = payload.updatedAt;
          settings.pendingScheduleNotice = null;
          hasLocalEdits = false;
          saveSettings();
          renderScheduleNotice();
          updateGroupUI();
          if (statusEl) {
            if (statusEl === groupStatus) {
              statusEl.className = "group-status success";
              statusEl.textContent = "\u2713 Published updates to group " + code + "!";
            } else {
              statusEl.style.display = "block";
              statusEl.style.color = "#A5D6A7";
              statusEl.style.background = "rgba(124, 214, 162, 0.1)";
              statusEl.textContent = "\u2713 Saved & published to group " + code + "!";
            }
          }
          if (groupStatus && statusEl !== groupStatus) {
            groupStatus.className = "group-status success";
            groupStatus.textContent = "\u2713 Published updates to group " + code + "!";
          }
        });
      });
    }).catch(function(err) {
      if (statusEl) {
        if (statusEl === groupStatus) {
          statusEl.className = "group-status error";
          statusEl.textContent = err.message;
        } else {
          statusEl.style.display = "block";
          statusEl.style.color = "var(--status-risky-fg)";
          statusEl.style.background = "rgba(242, 139, 130, 0.1)";
          statusEl.textContent = err.message;
        }
      }
      showError(err.message);
    });
  }

  if (btnGroupPush) {
    btnGroupPush.addEventListener("click", function() {
      publishScheduleToCloud(groupStatus);
    });
  }
  if (btnExamsSaveCloud) {
    btnExamsSaveCloud.addEventListener("click", function() {
      publishScheduleToCloud(examsCloudStatus);
    });
  }

  var lastAutoSyncTime = 0;
  function triggerAutoSync(force) {
    if (!settings || !settings.groupCode) return;
    if (settings.groupAutoSync === false) return;
    var now = Date.now();
    // Throttle silent syncs to once every 12 seconds unless forced
    if (!force && (now - lastAutoSyncTime < 12000)) return;
    lastAutoSyncTime = now;
    pullFromGroup(true);
  }

  // Pull Schedule from Cloud
  function pullFromGroup(silent) {
    if (!settings.groupCode) {
      if (!silent) showError("Please log in or enter a group code first.");
      return;
    }
    var code = settings.groupCode;
    var baseUrl = getFirebaseBaseUrl();

    if (!silent && groupStatus) {
      groupStatus.className = "group-status";
      groupStatus.textContent = "Pulling latest schedule for " + code + "\u2026";
    }

    var url = baseUrl + "/groups/" + encodeURIComponent(code) + ".json";
    fetch(url).then(function(res) {
      if (!res.ok) throw new Error("HTTP " + res.status);
      return res.json();
    }).then(function(data) {
      if (!data) {
        if (!silent && groupStatus) {
          groupStatus.className = "group-status";
          groupStatus.textContent = "Group " + code + " has no published schedule yet.";
        }
        return;
      }

      // Update user permissions if member profile exists
      if (settings.groupUsername) {
        var userKey = cleanUsername(settings.groupUsername);
        if (data.members && data.members[userKey]) {
          settings.groupUserRole = data.members[userKey].role || settings.groupUserRole;
          settings.groupPermissions = data.members[userKey].permissions || settings.groupPermissions;
        }
      }

      if (silent && hasLocalEdits) {
        // Active local modifications in this session; do not overwrite local schedule!
        return;
      }

      var changed = false;
      var changesList = [];
      if (data.schedule) {
        var s = data.schedule;
        if (JSON.stringify(settings.examDays || []) !== JSON.stringify(s.examDays || [])) {
          var eCount = (s.examDays || []).length;
          changesList.push(eCount + " exam date" + (eCount === 1 ? "" : "s"));
          settings.examDays = s.examDays || [];
          changed = true;
        }
        if (JSON.stringify(settings.prepLeaves || []) !== JSON.stringify(s.prepLeaves || [])) {
          var pCount = (s.prepLeaves || []).length;
          changesList.push(pCount + " prep off" + (pCount === 1 ? "" : "s"));
          settings.prepLeaves = s.prepLeaves || [];
          changed = true;
        }
        if (JSON.stringify(settings.holidays || []) !== JSON.stringify(s.holidays || [])) {
          var hCount = (s.holidays || []).length;
          changesList.push(hCount + " holiday" + (hCount === 1 ? "" : "s"));
          settings.holidays = s.holidays || [];
          changed = true;
        }
        if (s.windows && s.windows.length && JSON.stringify(settings.windows || []) !== JSON.stringify(s.windows)) {
          changesList.push("fee cutoff dates");
          settings.windows = s.windows;
          changed = true;
        }
        if (s.target != null && settings.target !== s.target) {
          changesList.push("target (" + s.target + "%)");
          settings.target = s.target;
          changed = true;
        }
        if (s.lecturesPerWeekday && JSON.stringify(settings.lecturesPerWeekday || {}) !== JSON.stringify(s.lecturesPerWeekday)) {
          changesList.push("daily timetable");
          settings.lecturesPerWeekday = s.lecturesPerWeekday;
          changed = true;
        }

        // Check if there is an incoming schedule change to notify about
        var isNewerUpdate = s.updatedAt && (s.updatedAt !== settings.lastAckedScheduleUpdate);
        if ((changed || isNewerUpdate) && s.updatedAt) {
          var byStr = s.updatedBy ? " by " + s.updatedBy : "";
          var desc = changesList.length
            ? changesList.join(" & ") + " updated. Safe skippable days recalculated!"
            : "Shared schedule was updated. Attendance recalculated!";
          settings.pendingScheduleNotice = {
            title: "Schedule Updated" + byStr + "!",
            body: desc,
            updatedAt: s.updatedAt
          };
        }
      }

      settings.groupLastSync = new Date().toISOString();
      saveSettings();

      if (changed || !silent) {
        renderAll();
      } else {
        renderScheduleNotice();
        updateGroupUI();
      }

      if (groupStatus) {
        groupStatus.className = "group-status success";
        var byNote = data.schedule && data.schedule.updatedBy ? " (by " + data.schedule.updatedBy + ")" : "";
        groupStatus.textContent = "\u2713 Synced with group " + code + byNote + "!";
      }
      checkOtaUpdate();
    }).catch(function(err) {
      if (!silent && groupStatus) {
        groupStatus.className = "group-status error";
        groupStatus.textContent = "Could not pull: " + err.message;
      }
    });
  }

  if (btnGroupPull) {
    btnGroupPull.addEventListener("click", function() {
      pullFromGroup(false);
    });
  }

  // Admin Member Permissions Management
  if (btnToggleAdminPanel) {
    btnToggleAdminPanel.addEventListener("click", function() {
      if (!adminPermSection) return;
      var isHidden = adminPermSection.style.display === "none";
      adminPermSection.style.display = isHidden ? "block" : "none";
      if (isHidden) {
        loadAndRenderAdminMembers();
      }
    });
  }

  if (btnRefreshMembers) {
    btnRefreshMembers.addEventListener("click", function() {
      loadAndRenderAdminMembers();
    });
  }

  function loadAndRenderAdminMembers() {
    if (!adminMemberList || !settings.groupCode) return;
    adminMemberList.innerHTML = '<p style="font-size:11.5px;color:var(--md-sys-color-on-surface-variant);padding:6px 0">Loading member list\u2026</p>';

    var baseUrl = getFirebaseBaseUrl();
    var url = baseUrl + "/groups/" + encodeURIComponent(settings.groupCode) + "/members.json";

    fetch(url).then(function(res) {
      if (!res.ok) throw new Error("HTTP " + res.status);
      return res.json();
    }).then(function(members) {
      if (!members || Object.keys(members).length === 0) {
        adminMemberList.innerHTML = '<p style="font-size:11.5px;color:var(--md-sys-color-on-surface-variant);padding:6px 0">No other members have joined this group yet.</p>';
        return;
      }

      var myKey = cleanUsername(settings.groupUsername);
      var html = "";

      Object.keys(members).forEach(function(uKey) {
        var m = members[uKey];
        var isMe = (uKey === myKey);
        var role = m.role || "viewer";
        var p = m.permissions || {};

        html += '<div class="admin-member-item" data-ukey="' + uKey + '">' +
          '<div class="member-item-top">' +
          '<span class="member-name-tag">' + escHtml(m.name || uKey) + (isMe ? ' <span style="font-size:10px;opacity:0.7">(You)</span>' : '') + '</span>' +
          '<select class="member-role-select" data-ukey="' + uKey + '"' + (isMe ? ' disabled' : '') + '>' +
          '<option value="admin"' + (role === "admin" ? ' selected' : '') + '>👑 Admin (Full Control)</option>' +
          '<option value="editor"' + (role === "editor" ? ' selected' : '') + '>✏️ Editor (Custom Perms)</option>' +
          '<option value="viewer"' + (role === "viewer" ? ' selected' : '') + '>👁️ Student (Read-Only)</option>' +
          '</select>' +
          '</div>' +
          '<div class="perm-checkbox-grid">' +
          '<label class="perm-chk-label"><input type="checkbox" class="chk-perm" data-perm="canEditWindows" data-ukey="' + uKey + '"' + (p.canEditWindows || role === "admin" ? ' checked' : '') + (role === "admin" ? ' disabled' : '') + ' /> <span>Edit Cut-Off Dates</span></label>' +
          '<label class="perm-chk-label"><input type="checkbox" class="chk-perm" data-perm="canEditExams" data-ukey="' + uKey + '"' + (p.canEditExams || role === "admin" ? ' checked' : '') + (role === "admin" ? ' disabled' : '') + ' /> <span>Edit Exams &amp; Offs</span></label>' +
          '<label class="perm-chk-label"><input type="checkbox" class="chk-perm" data-perm="canEditHolidays" data-ukey="' + uKey + '"' + (p.canEditHolidays || role === "admin" ? ' checked' : '') + (role === "admin" ? ' disabled' : '') + ' /> <span>Edit Holidays</span></label>' +
          '<label class="perm-chk-label"><input type="checkbox" class="chk-perm" data-perm="canEditLectures" data-ukey="' + uKey + '"' + (p.canEditLectures || role === "admin" ? ' checked' : '') + (role === "admin" ? ' disabled' : '') + ' /> <span>Edit Lectures/Day</span></label>' +
          '</div>' +
          (!isMe ? '<div style="display:flex;justify-content:flex-end;margin-top:2px"><button class="btn-text btn-del-member" data-ukey="' + uKey + '" style="color:var(--status-risky-fg);font-size:10.5px">Remove Member</button></div>' : '') +
          '</div>';
      });

      adminMemberList.innerHTML = html;

      // Handle Role change updates
      adminMemberList.querySelectorAll(".member-role-select").forEach(function(sel) {
        sel.addEventListener("change", function() {
          var uKey = sel.dataset.ukey;
          var newRole = sel.value;
          var item = adminMemberList.querySelector('.admin-member-item[data-ukey="' + uKey + '"]');
          if (item) {
            item.querySelectorAll(".chk-perm").forEach(function(chk) {
              if (newRole === "admin") {
                chk.checked = true;
                chk.disabled = true;
              } else if (newRole === "viewer") {
                chk.checked = false;
                chk.disabled = false;
              } else {
                chk.disabled = false;
              }
            });
          }
        });
      });

      // Handle Remove Member
      adminMemberList.querySelectorAll(".btn-del-member").forEach(function(btn) {
        btn.addEventListener("click", function() {
          var uKey = btn.dataset.ukey;
          if (!confirm("Are you sure you want to remove member '" + uKey + "' from this group?")) return;
          var delUrl = baseUrl + "/groups/" + encodeURIComponent(settings.groupCode) + "/members/" + encodeURIComponent(uKey) + ".json";
          fetch(delUrl, { method: "DELETE" }).then(function() {
            loadAndRenderAdminMembers();
          });
        });
      });
    }).catch(function(err) {
      adminMemberList.innerHTML = '<p style="font-size:11.5px;color:var(--status-risky-fg);padding:6px 0">Error loading members: ' + err.message + '</p>';
    });
  }

  // Save Member Permissions to Cloud
  if (btnSaveMemberPerms) {
    btnSaveMemberPerms.addEventListener("click", function() {
      clearError();
      if (!settings.groupCode || settings.groupUserRole !== "admin") {
        showError("Only the group Admin can save member permissions.");
        return;
      }
      var baseUrl = getFirebaseBaseUrl();
      var items = adminMemberList.querySelectorAll(".admin-member-item");
      if (!items.length) return;

      var updates = {};
      items.forEach(function(item) {
        var uKey = item.dataset.ukey;
        var roleSel = item.querySelector(".member-role-select");
        var role = roleSel ? roleSel.value : "viewer";

        var perms = {
          canEditWindows: !!item.querySelector('.chk-perm[data-perm="canEditWindows"]').checked,
          canEditExams: !!item.querySelector('.chk-perm[data-perm="canEditExams"]').checked,
          canEditHolidays: !!item.querySelector('.chk-perm[data-perm="canEditHolidays"]').checked,
          canEditLectures: !!item.querySelector('.chk-perm[data-perm="canEditLectures"]').checked,
          canManageMembers: (role === "admin")
        };

        updates[uKey + "/role"] = role;
        updates[uKey + "/permissions"] = perms;
      });

      var patchUrl = baseUrl + "/groups/" + encodeURIComponent(settings.groupCode) + "/members.json";
      fetch(patchUrl, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates)
      }).then(function(res) {
        if (!res.ok) throw new Error("Failed to save member permissions.");
        showWarnings(["✓ Member permissions successfully updated in the cloud!"]);
        loadAndRenderAdminMembers();
      }).catch(function(err) {
        showError("Error saving permissions: " + err.message);
      });
    });
  }

  // App Version & OTA Update Notification System
  function compareSemver(v1, v2) {
    var p1 = String(v1 || "0").split(".").map(Number);
    var p2 = String(v2 || "0").split(".").map(Number);
    for (var i = 0; i < Math.max(p1.length, p2.length); i++) {
      var n1 = p1[i] || 0;
      var n2 = p2[i] || 0;
      if (n1 > n2) return 1;
      if (n1 < n2) return -1;
    }
    return 0;
  }

  function checkOtaUpdate(manual) {
    var myVersion = (chrome.runtime && chrome.runtime.getManifest)
                    ? chrome.runtime.getManifest().version : "2.1";
    if (curVerTag) curVerTag.textContent = "v" + myVersion;
    if (appUpdateStatus && manual) appUpdateStatus.textContent = "Checking cloud for updates\u2026";

    var baseUrl = getFirebaseBaseUrl();
    var url = baseUrl + "/meta/app_version.json";
    fetch(url).then(function(res) {
      if (!res.ok) throw new Error("HTTP " + res.status);
      return res.json();
    }).then(function(verInfo) {
      if (!verInfo || !verInfo.latestVersion) {
        if (appUpdateStatus) appUpdateStatus.textContent = "✓ Up to date (v" + myVersion + ")";
        if (otaBanner) otaBanner.style.display = "none";
        return;
      }
      if (compareSemver(verInfo.latestVersion, myVersion) > 0) {
        if (appUpdateStatus) {
          appUpdateStatus.textContent = "🚀 Update available: v" + verInfo.latestVersion;
        }
        if (otaBanner) {
          otaBanner.style.display = "block";
          if (otaTitle) otaTitle.textContent = "Update Available (v" + verInfo.latestVersion + ")";
          if (otaNotes && verInfo.notes) otaNotes.textContent = verInfo.notes;
        }
      } else {
        if (appUpdateStatus) appUpdateStatus.textContent = "✓ Up to date (v" + myVersion + ")";
        if (otaBanner) otaBanner.style.display = "none";
      }
    }).catch(function(err) {
      if (appUpdateStatus) {
        appUpdateStatus.textContent = manual ? "Could not check: " + err.message : "✓ Installed: v" + myVersion;
      }
    });
  }

  if (btnManualCheckOta) {
    btnManualCheckOta.addEventListener("click", function() {
      checkOtaUpdate(true);
    });
  }

  if (btnOtaReloadApp) {
    btnOtaReloadApp.addEventListener("click", function() {
      if (chrome.runtime && chrome.runtime.reload) {
        chrome.runtime.reload();
      } else {
        location.reload();
      }
    });
  }

  if (btnOtaHow && updateGuideModal) {
    btnOtaHow.addEventListener("click", function() {
      updateGuideModal.style.display = "flex";
    });
  }
  if (btnCloseUpdateGuide && updateGuideModal) {
    btnCloseUpdateGuide.addEventListener("click", function() {
      updateGuideModal.style.display = "none";
    });
  }
  if (updateGuideModal) {
    updateGuideModal.addEventListener("click", function(e) {
      if (e.target === updateGuideModal) updateGuideModal.style.display = "none";
    });
  }
  if (btnModalOpenExt) {
    btnModalOpenExt.addEventListener("click", function() {
      chrome.tabs.create({ url: "chrome://extensions" });
    });
  }
  if (btnModalReload) {
    btnModalReload.addEventListener("click", function() {
      if (chrome.runtime && chrome.runtime.reload) {
        chrome.runtime.reload();
      } else {
        location.reload();
      }
    });
  }

  if (btnAdminBroadcastOta) {
    btnAdminBroadcastOta.addEventListener("click", function() {
      clearError();
      if (!isDevUser()) {
        showError("Unauthorized: Only authorized maintainers can broadcast app release notifications.");
        return;
      }
      if (!settings.groupCode || settings.groupUserRole !== "admin") {
        showError("Only the group Admin can broadcast app update notices.");
        return;
      }
      var newVer = (adminOtaVer ? adminOtaVer.value : "").trim();
      var dlUrl = (adminOtaUrl ? adminOtaUrl.value : "").trim();
      if (!dlUrl) {
        dlUrl = "https://github.com/Colaup747/attendance-calc/raw/main/attendance.zip";
      }
      var notes = (adminOtaNotes ? adminOtaNotes.value : "").trim();

      if (!newVer) {
        showError("Please enter a version number (e.g. 1.0.1).");
        return;
      }
      var payload = {
        latestVersion: newVer,
        downloadUrl: dlUrl,
        notes: notes || "New features and bug fixes.",
        broadcastBy: settings.groupUsername,
        broadcastAt: new Date().toISOString()
      };
      var baseUrl = getFirebaseBaseUrl();
      var url = baseUrl + "/meta/app_version.json";
      fetch(url, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      }).then(function(res) {
        if (!res.ok) throw new Error("Failed to broadcast update notice.");
        showWarnings(["✓ Update v" + newVer + " notice broadcasted to all students!"]);
        checkOtaUpdate(true);
      }).catch(function(err) {
        showError("Broadcast failed: " + err.message);
      });
    });
  }

  var verClickCount = 0;
  if (curVerTag) {
    curVerTag.style.cursor = "pointer";
    curVerTag.title = "Installed Version: v3.0.7";
    curVerTag.addEventListener("click", function() {
      verClickCount++;
      if (verClickCount >= 3) {
        verClickCount = 0;
        var pass = prompt("Developer Mode Access Key:");
        if (pass && pass.trim() === "cola747") {
          settings.isDevMode = true;
          saveSettings();
          updateGroupUI();
          showWarnings(["✓ Developer mode unlocked for this browser."]);
        }
      }
    });
  }

  // WhatsApp Share Code
  if (btnShareCode) {
    btnShareCode.addEventListener("click", function() {
      var bundle = {
        code:       settings.groupCode || "CLASS",
        examDays:   settings.examDays || [],
        prepLeaves: settings.prepLeaves || [],
        holidays:   settings.holidays || [],
        windows:    settings.windows || [],
      };
      var str = "PGC#" + btoa(unescape(encodeURIComponent(JSON.stringify(bundle))));
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(str).then(function() {
          if (groupStatus) {
            groupStatus.className = "group-status success";
            groupStatus.textContent = "\u2713 Share Code copied to clipboard! Share it in your class WhatsApp group.";
          }
        }).catch(function() {
          prompt("Copy this share code to send to classmates:", str);
        });
      } else {
        prompt("Copy this share code to send to classmates:", str);
      }
    });
  }

  /* ── windows ──────────────────────────────────────────────── */
  function renderWindowsList() {
    windowsList.innerHTML = settings.windows.map(function(w, i) {
      return '<div class="window-item" data-idx="' + i + '">' +
        '<div class="window-item-header">' +
        '<input class="window-item-name" type="text" value="' + escHtml(w.name) +
        '" data-idx="' + i + '" aria-label="Window name" />' +
        '<button class="win-del-btn btn-small danger" data-idx="' + i +
        '" style="padding:3px 8px;font-size:12px" aria-label="Delete ' + escHtml(w.name) + '">&#10005;</button>' +
        '</div>' +
        '<div class="window-item-dates">' +
        '<input type="date" class="win-start" value="' + w.start + '" data-idx="' + i + '" aria-label="Start date" />' +
        '<span class="sep">\u2192</span>' +
        '<input type="date" class="win-end" value="' + w.end + '" data-idx="' + i + '" aria-label="End date" />' +
        '</div></div>';
    }).join("");

    windowsList.querySelectorAll(".window-item-name").forEach(function(inp) {
      inp.addEventListener("input", function() {
        settings.windows[Number(inp.dataset.idx)].name = inp.value;
        saveSettings();
        rebuildWindowSelect();
      });
    });

    windowsList.querySelectorAll(".win-start").forEach(function(inp) {
      function onStartChange() {
        var i = Number(inp.dataset.idx);
        settings.windows[i].start = inp.value;
        validateWin(i);
        saveSettings();
        checkOverlap();
        rebuildWindowSelect();
        renderResult();
      }
      inp.addEventListener("input", onStartChange);
      inp.addEventListener("change", onStartChange);
    });

    windowsList.querySelectorAll(".win-end").forEach(function(inp) {
      function onEndChange() {
        var i = Number(inp.dataset.idx);
        settings.windows[i].end = inp.value;
        validateWin(i);
        saveSettings();
        checkOverlap();
        rebuildWindowSelect();
        renderResult();
      }
      inp.addEventListener("input", onEndChange);
      inp.addEventListener("change", onEndChange);
    });

    windowsList.querySelectorAll(".win-del-btn").forEach(function(btn) {
      btn.addEventListener("click", function() {
        var i = Number(btn.dataset.idx);
        settings.windows.splice(i, 1);
        if (activeWindowIdx >= settings.windows.length)
          activeWindowIdx = Math.max(0, settings.windows.length - 1);
        saveSettings();
        renderWindowsList();
        checkOverlap();
        rebuildWindowSelect();
        renderResult();
      });
    });

    checkOverlap();
  }

  function validateWin(i) {
    var w = settings.windows[i];
    if (w && w.start && w.end && w.start > w.end) {
      var t = w.start; w.start = w.end; w.end = t;
    }
  }

  function checkOverlap() {
    var wins = settings.windows || [];
    var conflictIndices = new Set();
    if (wins.length > 1) {
      var sorted = wins.map(function(w, idx) { return { w: w, idx: idx }; }).sort(function(a, b) {
        if (!a.w.start) return 1;
        if (!b.w.start) return -1;
        return a.w.start < b.w.start ? -1 : (a.w.start > b.w.start ? 1 : 0);
      });
      for (var i = 1; i < sorted.length; i++) {
        var prev = sorted[i - 1].w;
        var curr = sorted[i].w;
        if (curr.start && prev.end && curr.start <= prev.end) {
          conflictIndices.add(sorted[i - 1].idx);
          conflictIndices.add(sorted[i].idx);
        }
      }
    }
    overlapWarn.classList.toggle("visible", conflictIndices.size > 0);
    windowsList.querySelectorAll(".window-item").forEach(function(el) {
      var idx = Number(el.dataset.idx);
      el.classList.toggle("has-conflict", conflictIndices.has(idx));
    });
  }

  btnAddWindow.addEventListener("click", function() {
    var wins = settings.windows;
    var startD = todayStr();
    var endD = todayStr();
    if (wins.length > 0) {
      var lastWin = wins[wins.length - 1];
      if (lastWin && lastWin.end) {
        function parseD(s){ var p=s.split("-").map(Number); return new Date(Date.UTC(p[0],p[1]-1,p[2])); }
        function fmtD(dt){ return dt.toISOString().slice(0,10); }
        function addD(s,n){ var dt=parseD(s); dt.setUTCDate(dt.getUTCDate()+n); return fmtD(dt); }
        startD = addD(lastWin.end, 1);
        endD = addD(lastWin.end, 30);
      }
    }
    settings.windows.push({
      name: "Installment No. " + (wins.length + 2),
      start: startD,
      end: endD
    });
    saveSettings();
    renderWindowsList();
    checkOverlap();
    rebuildWindowSelect();
    renderResult();
  });

  btnResetWindows.addEventListener("click", function() {
    settings.windows = DEFAULT_WINDOWS.map(function(w) { return Object.assign({}, w); });
    activeWindowIdx = 0;
    saveSettings();
    renderWindowsList();
    checkOverlap();
    rebuildWindowSelect();
    renderResult();
  });

  function rebuildWindowSelect() {
    var wins=settings.windows;
    windowSelect.innerHTML=wins.map(function(w,i){
      return '<option value="'+i+'">'+escHtml(w.name)+
             " ("+w.start+" \u2013 "+w.end+")</option>";
    }).join("");
    if(activeWindowIdx>=wins.length) activeWindowIdx=Math.max(0,wins.length-1);
    windowSelect.value=String(activeWindowIdx);
    updateQuickEnd();
  }

  /* ── kick off ─────────────────────────────────────────────── */
  loadAll().then(function(){
    renderAll();
    triggerAutoSync(true); // Auto-sync schedule when popup is first opened
    checkOtaUpdate();      // Check if new extension version was released
  }).catch(function(e){
    showError("Failed to load storage: "+e.message);
  });

} // end init()
