@echo off
setlocal
if exist "%~dp0updater\windows-update.bat" (
    call "%~dp0updater\windows-update.bat" %*
    exit /b %ERRORLEVEL%
) else (
    echo [!] updater\windows-update.bat not found.
    pause
    exit /b 1
)
